"""
tesseract_decoder.py — 5D Gravity Message Decoder & Quantum Gravity Engine
ENDURANCE Mission Control | Interstellar Science Platform v3.0.0
═══════════════════════════════════════════════════════════════════════════════
References:
  [1] Kip Thorne, "The Science of Interstellar" (W.W. Norton, 2014)
  [2] Misner, Thorne & Wheeler, "Gravitation" (Freeman, 1973)
  [3] Penrose (1965) — Singularity theorem & causal structure
  [4] DeWitt (1967) — Quantum gravity canonical approach
  [5] Hawking & Penrose (1970) — Singularity theorems
  [6] Rovelli (2004) — Loop quantum gravity
  [7] Ashtekar (1986) — New variables for classical & quantum gravity
  [8] Wheeler (1955) — Quantum foam / spacetime at Planck scale

Module implements:
  ┌─ GRAVITY SIGNAL SYSTEM ─────────────────────────────────────────────────┐
  │ Binary gravity encoding: pulse = 1, silence = 0                        │
  │ Planck-scale gravity manipulation from 5D bulk                         │
  │ Cooper's watch encoding: second-hand deflection pattern                 │
  │ Dust grain displacement patterns → binary code                         │
  │ Morse-gravity hybrid encoding for redundancy                            │
  │ Signal authentication and checksum verification                         │
  │ Cooper coordinate encoding: N40°53'23" W83°51'23" → binary             │
  │ Gravity signal SNR analysis and noise floor estimation                  │
  └──────────────────────────────────────────────────────────────────────────┘
  ┌─ TESSERACT GEOMETRY ────────────────────────────────────────────────────┐
  │ 5D spacetime coordinate system (x,y,z,t,w) where w=bulk dimension      │
  │ Tesseract as 4D hypercube projected into 3D (observable section)       │
  │ Bookshelf grid: 3D shelves ↔ 4D spacetime cross-sections              │
  │ Gravity as inter-dimensional force: T_μν coupling across branes        │
  │ Causal structure within tesseract (past light cone accessible)         │
  │ Cooper navigation: translate 5D coords to bookshelf position           │
  │ Message routing: bulk→brane coupling efficiency                         │
  └──────────────────────────────────────────────────────────────────────────┘
  ┌─ MURPHY'S EQUATION SOLVER ─────────────────────────────────────────────┐
  │ Quantum gravity singularity equation (symbolic + numerical)            │
  │ Gravitational anomaly data from Gargantua singularity                  │
  │ Wheeler-DeWitt equation: Ĥ|Ψ⟩ = 0 (canonical quantum gravity)        │
  │ Loop quantum gravity spin-network states                               │
  │ Singularity data → equation completion → Plan A solution               │
  │ TARS data crystal: encoded singularity quantum state data              │
  │ Equation convergence analysis and solution verification                 │
  └──────────────────────────────────────────────────────────────────────────┘
  ┌─ BOOKSHELF DECODER ─────────────────────────────────────────────────────┐
  │ Shelf grid: row×column→bit mapping                                     │
  │ Book displacement amplitude → bit value                                │
  │ Multi-layer decoding: primary + parity + error correction              │
  │ Message reconstruction from partial/noisy displacement data            │
  │ ASCII/UTF-8 message extraction from gravity signal                     │
  │ Rate encoding: bits per gravity pulse                                   │
  └──────────────────────────────────────────────────────────────────────────┘
"""
from __future__ import annotations

import hashlib
import math
import time
import uuid
import warnings
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import scipy.signal    as sci_sig
import scipy.fft       as sci_fft
import scipy.optimize  as sci_opt
import scipy.special   as sci_sp

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot   as plt
import matplotlib.gridspec as gridspec
import matplotlib.colors   as mcolors
from matplotlib.colors     import LinearSegmentedColormap
import matplotlib.patches  as mpatches

import streamlit as st

warnings.filterwarnings("ignore")

# ══════════════════════════════════════════════════════════════════════════════
# §1  CONSTANTS
# ══════════════════════════════════════════════════════════════════════════════
G_SI      = 6.674_30e-11
C_SI      = 2.997_924_58e8
HBAR      = 1.054_571_817e-34
K_B       = 1.380_649e-23
L_PLANCK  = 1.616_255e-35     # Planck length [m]
T_PLANCK  = 5.391_247e-44     # Planck time [s]
M_PLANCK  = 2.176_434e-8      # Planck mass [kg]
E_PLANCK  = M_PLANCK*C_SI**2  # Planck energy [J]
YEAR_S    = 3.155_760e7
HOUR_S    = 3_600.0

# Cooper's actual NASA coordinates (binary-encoded via bookshelf)
COOPER_NASA_LAT_DEG  = 40.0 + 53/60 + 23/3600   # N 40°53′23″
COOPER_NASA_LON_DEG  = -(83.0 + 51/60 + 23/3600) # W 83°51′23″

# Tesseract parameters (Thorne canon [1])
TESSERACT_DIM        = 5       # dimensions (4 spacetime + 1 bulk)
BOOKSHELF_ROWS       = 10      # number of shelf rows in Cooper's room
BOOKSHELF_COLS_PER   = 30      # books per shelf
WATCH_HAND_BITS      = 60      # 60-second face = 60 bit positions

# TARS data crystal capacity (estimated)
TARS_CRYSTAL_BITS    = 2**40   # ~1 terabit

# ══════════════════════════════════════════════════════════════════════════════
# §2  ENUMERATIONS
# ══════════════════════════════════════════════════════════════════════════════
class EncodingScheme(Enum):
    BINARY_DUST     = "Binary dust displacement (books)"
    WATCH_SECOND    = "Watch second-hand deflection"
    GRAVITY_MORSE   = "Gravity-Morse hybrid"
    QUANTUM_SPIN    = "Quantum spin-network states"
    COORDINATE_PACK = "Coordinate-packed binary"

class MessageType(Enum):
    COORDINATES     = "GPS/Coordinate data"
    EQUATION        = "Mathematical equation"
    BINARY_DATA     = "Raw binary data stream"
    QUANTUM_STATE   = "Quantum gravity state"
    CONFIRMATION    = "Mission confirmation"

class DecoderState(Enum):
    IDLE       = "IDLE — awaiting signal"
    SCANNING   = "SCANNING — detecting gravity pulses"
    DECODING   = "DECODING — extracting bits"
    VERIFIED   = "VERIFIED — checksum passed"
    ERROR      = "ERROR — checksum failed"
    COMPLETE   = "COMPLETE — message reconstructed"

class GravitySignalQuality(Enum):
    EXCELLENT = "EXCELLENT (SNR > 20 dB)"
    GOOD      = "GOOD (10–20 dB)"
    FAIR      = "FAIR (5–10 dB)"
    POOR      = "POOR (0–5 dB)"
    NOISE     = "NOISE (SNR < 0 dB)"

class EquationSolveStatus(Enum):
    INCOMPLETE  = "INCOMPLETE — missing singularity data"
    PARTIAL     = "PARTIAL — approximate solution"
    SOLVED      = "SOLVED — exact quantum gravity solution"
    VERIFIED    = "VERIFIED — cross-validated"
    PLAN_A_READY= "PLAN A READY — gravity equation complete"

# ══════════════════════════════════════════════════════════════════════════════
# §3  GRAVITY SIGNAL ENCODER / DECODER
# ══════════════════════════════════════════════════════════════════════════════
class GravitySignalCodec:
    """
    Encodes arbitrary data into gravity pulse sequences and decodes them.
    Physical mechanism: Cooper manipulates gravity amplitude from within
    the tesseract, creating detectable displacements of physical objects
    (books, watch hands, dust) in the past timeline.

    Encoding: NRZ-L (Non-Return-to-Zero Level)
      Gravity pulse present  → bit 1
      Gravity pulse absent   → bit 0
    Frame format:
      [8-bit preamble 0xAA] [16-bit length] [N-bit payload] [8-bit CRC]
    """

    PREAMBLE     = 0b10101010   # 0xAA — sync word
    PREAMBLE_BITS= 8
    LENGTH_BITS  = 16
    CRC_BITS     = 8
    HEADER_BITS  = PREAMBLE_BITS + LENGTH_BITS

    # Gravity pulse physical parameters
    PULSE_DURATION_S   = 0.5    # duration of one gravity pulse [s]
    PULSE_AMPLITUDE_G  = 1e-6   # peak gravity perturbation [m/s²]
    PLANCK_COUPLING    = HBAR * C_SI**5 / G_SI**2  # Planck-scale coupling

    def __init__(self, snr_db: float = 15.0):
        self.snr_db   = snr_db
        self.snr_lin  = 10**(snr_db/10.0)
        self.noise_amp = self.PULSE_AMPLITUDE_G / math.sqrt(self.snr_lin)

    # ── §3.1  Encoding ────────────────────────────────────────────────────────
    def text_to_bits(self, text: str) -> List[int]:
        """UTF-8 text → bit list (MSB first per byte)."""
        bits = []
        for byte in text.encode("utf-8"):
            for shift in range(7, -1, -1):
                bits.append((byte >> shift) & 1)
        return bits

    def int_to_bits(self, value: int, n_bits: int) -> List[int]:
        """Integer → n_bits list (MSB first)."""
        return [(value >> i) & 1 for i in range(n_bits-1, -1, -1)]

    def crc8(self, bits: List[int]) -> int:
        """CRC-8/MAXIM polynomial 0x31."""
        crc = 0xFF
        for byte_start in range(0, len(bits), 8):
            byte = 0
            for b in bits[byte_start:byte_start+8]:
                byte = (byte << 1) | b
            crc ^= byte
            for _ in range(8):
                if crc & 0x80:
                    crc = ((crc << 1) ^ 0x31) & 0xFF
                else:
                    crc = (crc << 1) & 0xFF
        return crc

    def encode_message(self, message: str,
                        scheme: EncodingScheme = EncodingScheme.BINARY_DUST
                        ) -> Dict[str, Any]:
        """
        Encode a text message into gravity pulse sequence.
        Returns full frame bits + physical signal array.
        """
        payload_bits = self.text_to_bits(message)
        n_payload    = len(payload_bits)
        crc          = self.crc8(payload_bits)
        crc_bits     = self.int_to_bits(crc, 8)

        frame = (self.int_to_bits(self.PREAMBLE, 8) +
                 self.int_to_bits(n_payload, 16) +
                 payload_bits +
                 crc_bits)

        # Physical signal: gravity amplitude time series
        T   = self.PULSE_DURATION_S
        fs  = 100.0   # samples per second
        n_s = int(T * fs)
        sig = np.zeros(len(frame) * n_s)
        for i, bit in enumerate(frame):
            if bit == 1:
                t_local = np.linspace(0, T, n_s)
                pulse   = self.PULSE_AMPLITUDE_G * np.sin(math.pi * t_local/T)**2
                sig[i*n_s:(i+1)*n_s] = pulse

        # Add noise
        noise = np.random.randn(len(sig)) * self.noise_amp
        sig_noisy = sig + noise
        t_arr     = np.arange(len(sig)) / fs

        return {
            "message":       message,
            "scheme":        scheme.value,
            "frame_bits":    frame,
            "payload_bits":  payload_bits,
            "n_bits":        len(frame),
            "n_payload_bits":n_payload,
            "n_bytes":       (n_payload + 7)//8,
            "crc8":          crc,
            "t_arr":         t_arr,
            "signal_clean":  sig,
            "signal_noisy":  sig_noisy,
            "snr_db":        self.snr_db,
            "duration_s":    len(frame) * T,
            "bit_rate_bps":  1.0/T,
        }

    # ── §3.2  Coordinate encoding ─────────────────────────────────────────────
    def encode_coordinates(self, lat: float, lon: float) -> Dict[str, Any]:
        """
        Encode GPS coordinates as binary gravity pulses.
        Cooper's NASA coordinates: N40°53'23" W83°51'23"
        Encoded as: [sign][degrees_7bit][minutes_6bit][seconds_6bit]
        Total per coordinate: 20 bits; both: 40 bits.
        Format used: decimal degrees × 10^5, as signed 24-bit integer.
        """
        def coord_to_bits(val: float) -> List[int]:
            sign   = 0 if val >= 0 else 1
            deg    = int(abs(val))
            rem    = abs(val) - deg
            mins   = int(rem * 60)
            secs   = round((rem * 60 - mins) * 60)
            bits   = ([sign]
                      + self.int_to_bits(deg,  7)
                      + self.int_to_bits(mins, 6)
                      + self.int_to_bits(secs, 6))
            return bits

        lat_bits   = coord_to_bits(lat)
        lon_bits   = coord_to_bits(lon)
        all_bits   = lat_bits + lon_bits
        crc        = self.crc8(all_bits)
        frame_bits = all_bits + self.int_to_bits(crc, 8)

        # Dust displacement physical representation
        dust_pattern = np.array(frame_bits, dtype=float)
        # Displacement: bit=1 → 2 mm displacement, bit=0 → 0
        displacement_mm = dust_pattern * 2.0
        # Add thermal noise (~0.1 mm)
        displacement_mm += np.random.randn(len(dust_pattern)) * 0.1

        # Verify decoding
        decoded_lat  = self._bits_to_coord(frame_bits[:20])
        decoded_lon  = self._bits_to_coord(frame_bits[20:40])

        return {
            "lat_original": lat, "lon_original": lon,
            "lat_bits": lat_bits, "lon_bits": lon_bits,
            "frame_bits": frame_bits, "crc8": crc,
            "displacement_mm": displacement_mm,
            "n_total_bits": len(frame_bits),
            "decoded_lat": decoded_lat, "decoded_lon": decoded_lon,
            "encode_error_lat_arcsec": abs(lat - decoded_lat)*3600,
            "encode_error_lon_arcsec": abs(lon - decoded_lon)*3600,
        }

    def _bits_to_coord(self, bits: List[int]) -> float:
        """Decode 20 coordinate bits back to decimal degrees."""
        if len(bits) < 20:
            return 0.0
        sign = -1.0 if bits[0] else 1.0
        deg  = sum(bits[1+i] << (6-i) for i in range(7))
        mins = sum(bits[8+i] << (5-i) for i in range(6))
        secs = sum(bits[14+i] << (5-i) for i in range(6))
        return sign * (deg + mins/60.0 + secs/3600.0)

    # ── §3.3  Watch hand decoder ──────────────────────────────────────────────
    def decode_watch_hands(self, second_positions: np.ndarray) -> Dict[str, Any]:
        """
        Decode binary message from watch second-hand positions.
        Position > 30 seconds → bit 1 (hand pointing right half)
        Position ≤ 30 seconds → bit 0 (hand pointing left half)
        Threshold method: quantize to binary from position sequence.
        Cooper manipulated the watch hands to encode singularity data [1].
        """
        bits   = [1 if p > 30.0 else 0 for p in second_positions]
        # Extract payload (assume header stripped)
        byte_arr = []
        for i in range(0, len(bits)-7, 8):
            byte = 0
            for j in range(8):
                byte |= bits[i+j] << (7-j)
            byte_arr.append(byte)
        # Attempt ASCII decode
        try:
            text = bytes(byte_arr).decode("utf-8", errors="replace")
        except Exception:
            text = "".join(chr(b) if 32 <= b < 127 else "." for b in byte_arr)
        snr_estimate = self._estimate_snr(np.array(second_positions), 30.0)
        return {
            "n_positions": len(second_positions),
            "bits":        bits,
            "byte_values": byte_arr,
            "decoded_text": text.strip(),
            "n_bytes":     len(byte_arr),
            "snr_estimate_db": snr_estimate,
            "signal_quality": self._snr_to_quality(snr_estimate).value,
        }

    def _estimate_snr(self, signal: np.ndarray, threshold: float) -> float:
        sig_power   = np.var(signal - threshold)
        noise_power = np.var(signal % 1.0)
        return 10*math.log10(sig_power/(noise_power+1e-30)+1e-10)

    def _snr_to_quality(self, snr_db: float) -> GravitySignalQuality:
        if snr_db > 20:   return GravitySignalQuality.EXCELLENT
        if snr_db > 10:   return GravitySignalQuality.GOOD
        if snr_db > 5:    return GravitySignalQuality.FAIR
        if snr_db > 0:    return GravitySignalQuality.POOR
        return GravitySignalQuality.NOISE

    # ── §3.4  Decoding from noisy signal ─────────────────────────────────────
    def decode_signal(self, signal_noisy: np.ndarray,
                       fs: float = 100.0,
                       T_bit: float = 0.5) -> Dict[str, Any]:
        """
        Decode gravity pulse sequence from noisy time series.
        Method: matched filter with pulse template, then threshold.
        """
        # Template pulse
        n_s    = int(T_bit * fs)
        t_loc  = np.linspace(0, T_bit, n_s)
        tmpl   = self.PULSE_AMPLITUDE_G * np.sin(math.pi*t_loc/T_bit)**2
        # Matched filter (correlate)
        corr   = sci_sig.correlate(signal_noisy, tmpl, mode="valid")
        corr_n = corr / (np.max(np.abs(corr)) + 1e-30)
        # Sample at bit centres
        n_bits = len(signal_noisy) // n_s
        bits   = []
        for i in range(n_bits):
            centre = i*n_s + n_s//2
            if centre < len(corr_n):
                bits.append(1 if corr_n[centre] > 0.3 else 0)
        # Strip preamble and extract payload
        decoded_text  = ""
        preamble_found= False
        payload_start = 0
        for i in range(len(bits)-8):
            byte = sum(bits[i+j] << (7-j) for j in range(8))
            if byte == self.PREAMBLE:
                preamble_found = True
                payload_start  = i + 8
                break
        if preamble_found and payload_start+16 < len(bits):
            n_payload = sum(bits[payload_start+j] << (15-j)
                            for j in range(16))
            data_start = payload_start + 16
            if data_start + n_payload <= len(bits):
                payload = bits[data_start:data_start+n_payload]
                byte_arr= [sum(payload[k+b] << (7-b) for b in range(8))
                            for k in range(0, n_payload-7, 8)]
                try:
                    decoded_text = bytes(byte_arr).decode("utf-8", errors="replace")
                except Exception:
                    decoded_text = "".join(chr(b) if 32<=b<127 else "." for b in byte_arr)
        return {
            "bits":          bits,
            "n_bits":        len(bits),
            "preamble_found":preamble_found,
            "decoded_text":  decoded_text.strip(),
            "corr":          corr_n,
        }


# ══════════════════════════════════════════════════════════════════════════════
# §4  BOOKSHELF GRID DECODER
# ══════════════════════════════════════════════════════════════════════════════
class BookshelfDecoder:
    """
    Decodes messages encoded in book displacement patterns on Cooper's bookshelf.
    The bookshelf acts as a 2D binary array:
      Row = shelf number (0-indexed from bottom)
      Column = book position (left to right)
      Value = displacement magnitude (0 = in-place, 1 = displaced outward)
    Reading order: bottom row left-to-right, then next row, etc.
    """

    def __init__(self,
                 n_rows: int = BOOKSHELF_ROWS,
                 n_cols: int = BOOKSHELF_COLS_PER):
        self.n_rows  = n_rows
        self.n_cols  = n_cols
        self.n_total = n_rows * n_cols

    def generate_grid(self, message: str) -> np.ndarray:
        """
        Encode a message into a bookshelf displacement grid.
        Returns n_rows × n_cols binary array (0=in, 1=displaced).
        """
        codec     = GravitySignalCodec()
        bits      = codec.text_to_bits(message)
        # Pad to fill grid
        n_needed  = self.n_total
        bits_padded = bits[:n_needed] + [0]*(max(0, n_needed - len(bits)))
        grid      = np.array(bits_padded[:n_needed], dtype=float)
        grid      = grid.reshape(self.n_rows, self.n_cols)
        return grid

    def generate_coordinate_grid(self, lat: float = COOPER_NASA_LAT_DEG,
                                  lon: float = COOPER_NASA_LON_DEG) -> Dict[str, Any]:
        """Generate Cooper's NASA coordinate bookshelf pattern."""
        codec  = GravitySignalCodec()
        result = codec.encode_coordinates(lat, lon)
        bits   = result["frame_bits"]
        grid   = np.zeros((self.n_rows, self.n_cols))
        for idx, bit in enumerate(bits[:self.n_total]):
            r = idx // self.n_cols
            c = idx %  self.n_cols
            grid[r, c] = float(bit)
        return {**result, "grid": grid, "n_rows": self.n_rows,
                "n_cols": self.n_cols}

    def decode_grid(self, grid: np.ndarray,
                    threshold: float = 0.5) -> Dict[str, Any]:
        """
        Decode binary message from displacement grid.
        threshold: displacement magnitude above which bit=1.
        """
        binary = (grid >= threshold).astype(int)
        bits   = binary.flatten().tolist()
        codec  = GravitySignalCodec()
        # Try coordinate decode (first 48 bits)
        lat = codec._bits_to_coord(bits[:20])
        lon = codec._bits_to_coord(bits[20:40])
        # Try text decode
        byte_arr = []
        for i in range(0, len(bits)-7, 8):
            byte = sum(bits[i+j] << (7-j) for j in range(8))
            byte_arr.append(byte)
        try:
            text = bytes(byte_arr).decode("utf-8", errors="replace")
        except Exception:
            text = "".join(chr(b) if 32<=b<127 else "." for b in byte_arr)
        crc_ok = codec.crc8(bits[:len(bits)-8]) == sum(bits[-8+j] << (7-j) for j in range(8))
        return {
            "grid":          grid,
            "bits":          bits,
            "n_ones":        int(np.sum(binary)),
            "n_zeros":       int(np.sum(1-binary)),
            "density":       float(np.mean(binary)),
            "decoded_lat":   lat,
            "decoded_lon":   lon,
            "decoded_text":  text[:80].strip(),
            "crc_verified":  crc_ok,
        }

    def displacement_noise_grid(self, true_grid: np.ndarray,
                                 sigma_mm: float = 0.5) -> np.ndarray:
        """Add physical noise (thermal vibration) to displacement pattern."""
        noise = np.random.randn(*true_grid.shape) * sigma_mm/2.0
        noisy = true_grid + noise
        return np.clip(noisy, 0.0, 1.5)

    def correction_grid(self, received: np.ndarray,
                         sent: np.ndarray) -> Dict[str, float]:
        """Compare received vs sent grid — error analysis."""
        binary_r = (received >= 0.5).astype(int)
        binary_s = sent.astype(int)
        errors   = np.sum(binary_r != binary_s)
        ber      = errors / self.n_total
        return {"bit_errors": int(errors), "BER": ber,
                "accuracy_pct": (1-ber)*100}


# ══════════════════════════════════════════════════════════════════════════════
# §5  TESSERACT GEOMETRY ENGINE
# ══════════════════════════════════════════════════════════════════════════════
class TesseractGeometry:
    """
    5D tesseract spatial coordinate system for the bulk structure
    placed by evolved humanity ("They") for Cooper's use [1].
    The tesseract represents a 5D region where:
      Dimensions 1-3: physical space (x, y, z)
      Dimension 4:    time t (traversable as a spatial dimension inside tesseract)
      Dimension 5:    bulk/interstellar dimension w (gravity only)

    Bookshelf analogy: each shelf-column pair corresponds to a
    (t, x) coordinate in spacetime, allowing Cooper to access
    any point in his daughter's past timeline.
    """

    def __init__(self, room_size_m: Tuple[float,float,float] = (4.0, 3.5, 3.0)):
        self.Lx, self.Ly, self.Lz = room_size_m   # Cooper's room dimensions
        self.shelf_spacing_m  = 0.35   # vertical spacing between shelves
        self.book_spacing_m   = 0.06   # horizontal spacing between books

    def spacetime_to_shelf(self, t_rel: float,
                            x_rel: float) -> Tuple[int, int]:
        """
        Map (t, x) spacetime coordinate → (shelf_row, book_col).
        t_rel ∈ [0,1]: fraction of Murphy's childhood timeline
        x_rel ∈ [0,1]: spatial position along room
        """
        row = int(t_rel * BOOKSHELF_ROWS) % BOOKSHELF_ROWS
        col = int(x_rel * BOOKSHELF_COLS_PER) % BOOKSHELF_COLS_PER
        return row, col

    def shelf_to_spacetime(self, row: int, col: int) -> Tuple[float, float]:
        """Inverse mapping: shelf grid → normalised spacetime coordinates."""
        t_rel = row / BOOKSHELF_ROWS
        x_rel = col / BOOKSHELF_COLS_PER
        return t_rel, x_rel

    def bulk_displacement_field(self, message_grid: np.ndarray,
                                 n_x: int = 40, n_z: int = 40) -> np.ndarray:
        """
        Compute 2D gravity perturbation field in the room plane (xz)
        generated by Cooper manipulating bulk gravity to displace books.
        Field ∝ 1/r² from each displaced book position.
        """
        field = np.zeros((n_z, n_x))
        x_arr = np.linspace(0, self.Lx, n_x)
        z_arr = np.linspace(0, self.Lz, n_z)
        for r_idx in range(BOOKSHELF_ROWS):
            for c_idx in range(BOOKSHELF_COLS_PER):
                if message_grid[r_idx, c_idx] < 0.5:
                    continue
                # Physical position of this book
                x_book = c_idx * self.book_spacing_m
                z_book = r_idx * self.shelf_spacing_m
                # Gravity perturbation field (inverse square)
                for iz, z in enumerate(z_arr):
                    for ix, x in enumerate(x_arr):
                        r2 = (x-x_book)**2 + (z-z_book)**2 + 0.01
                        field[iz, ix] += 1e-8 / r2
        return field

    def tesseract_wireframe(self, n_pts: int = 30
                             ) -> Dict[str, np.ndarray]:
        """
        Generate 4D hypercube (tesseract) wireframe projected to 3D.
        Uses standard 4D rotation projection: w-axis collapses along a diagonal.
        Returns edge list for plotting.
        """
        # 4D unit hypercube vertices: 16 vertices in (x,y,z,w) ∈ {0,1}^4
        verts4d = np.array([[((i>>k)&1) for k in range(4)]
                             for i in range(16)], dtype=float)
        # Project to 3D: (x,y,z) = (x + 0.4w, y + 0.4w, z)
        proj_mat = np.array([[1.0, 0.0, 0.0, 0.4],
                              [0.0, 1.0, 0.0, 0.4],
                              [0.0, 0.0, 1.0, 0.0]])
        verts3d = (proj_mat @ verts4d.T).T

        # Edges: two vertices differ in exactly one bit
        edges = []
        for i in range(16):
            for j in range(i+1, 16):
                diff = int(verts4d[i] @ np.array([1,2,4,8])) ^ \
                       int(verts4d[j] @ np.array([1,2,4,8]))
                if bin(diff).count("1") == 1:
                    edges.append((i, j))

        return {"verts3d": verts3d, "verts4d": verts4d, "edges": edges}

    def cooper_navigation_path(self, target_times: List[float]) -> pd.DataFrame:
        """
        Compute Cooper's navigation path through tesseract to reach
        specific moments in Murph's timeline.
        """
        rows = []
        for t_norm in target_times:
            row, col = self.spacetime_to_shelf(t_norm, 0.5)
            t_rel, x_rel = self.shelf_to_spacetime(row, col)
            rows.append({
                "t_normalised":    t_norm,
                "shelf_row":       row,
                "book_col":        col,
                "z_physical_m":    row * self.shelf_spacing_m,
                "x_physical_m":    col * self.book_spacing_m,
                "murph_age_yr":    8.0 + t_norm * 15.0,  # Murph 8-23 range
                "accessible":      True,
            })
        return pd.DataFrame(rows)


# ══════════════════════════════════════════════════════════════════════════════
# §6  MURPHY'S EQUATION SOLVER
# ══════════════════════════════════════════════════════════════════════════════
class MurphyEquationSolver:
    """
    Quantum gravity singularity equation solver.
    Murphy's equation (Plan A) requires data from inside Gargantua's singularity
    to fully characterise the quantum gravitational field, enabling the gravity
    equation solution that lifts humanity off Earth.

    The equation is a generalised Wheeler-DeWitt equation [4] with singularity
    boundary data, solved via:
      1. Loop quantum gravity spin-network state representation
      2. Asymptotic boundary condition from Gargantua singularity
      3. Numerical integration using TARS data crystal (1 terabit)
      4. Convergence verification via holographic duality
    """

    # Wheeler-DeWitt operator parameters (symbolic)
    PLANCK_MASS_REDUCED = M_PLANCK / math.sqrt(8*math.pi)
    G_NEWTON_PLANCK     = G_SI / (L_PLANCK * C_SI**2)

    def __init__(self):
        self.singularity_data_available = False
        self.equation_status  = EquationSolveStatus.INCOMPLETE
        self.solution_vector  = None
        self.convergence_hist = []

    def wheeler_dewitt_equation(self, Psi: np.ndarray,
                                 h_ij: np.ndarray) -> np.ndarray:
        """
        Wheeler-DeWitt equation: Ĥ|Ψ⟩ = 0
        Ĥ = (16πG)⁻¹ G_{ijkl} π^{ij} π^{kl} − (16πG)/(√h)(³R − 2Λ)
        Simplified numerical version on minisuperspace (FRW universe):
          d²Ψ/da² − a²Ψ = 0  (harmonic oscillator in scale factor)
        Extended with singularity data input: adds source term S(a)
        from TARS crystal data.
        """
        n    = len(Psi)
        a    = np.linspace(0.01, 10.0, n)   # scale factor
        # Kinetic term (second derivative — finite difference)
        d2Psi = np.gradient(np.gradient(Psi, a), a)
        # Potential term (de Sitter: V = a²)
        V     = a**2 * Psi
        # Source term from singularity data (if available)
        S     = np.zeros(n)
        if self.singularity_data_available:
            # TARS data provides singularity boundary condition
            S = np.exp(-((a - 0.1)**2) / 0.005) * 0.5   # delta at a→0
        H_Psi = d2Psi - V + S
        return H_Psi

    def solve_iterative(self, n_pts: int = 200,
                         n_iter: int = 500,
                         tars_data_fraction: float = 0.0) -> Dict[str, Any]:
        """
        Iterative solver for the quantum gravity equation.
        tars_data_fraction: fraction of TARS singularity data incorporated (0–1).
        Solves for wave function Ψ(a) of the universe.
        Convergence: residual ||HΨ|| → 0
        """
        a_arr = np.linspace(0.001, 12.0, n_pts)
        # Initial guess: Gaussian
        Psi   = np.exp(-((a_arr - 3.0)**2)/2.0)
        Psi  /= np.sqrt(np.trapz(Psi**2, a_arr)) + 1e-30
        self.singularity_data_available = tars_data_fraction > 0.5
        residuals = []
        alpha     = 0.05  # learning rate
        for it in range(n_iter):
            H_Psi     = self.wheeler_dewitt_equation(Psi, None)
            residual  = float(np.sqrt(np.mean(H_Psi**2)))
            residuals.append(residual)
            # Gradient descent update
            Psi      -= alpha * H_Psi
            # Normalise
            norm      = math.sqrt(np.trapz(Psi**2, a_arr))
            Psi      /= norm + 1e-30
            # Adaptive convergence boost from TARS data
            if tars_data_fraction > 0 and residual < 0.1:
                alpha *= 1.05
            if residual < 1e-6 and tars_data_fraction > 0.9:
                break
        final_residual = residuals[-1]
        self.solution_vector  = Psi
        self.convergence_hist = residuals
        # Determine status
        if tars_data_fraction >= 0.99 and final_residual < 1e-5:
            self.equation_status = EquationSolveStatus.PLAN_A_READY
        elif tars_data_fraction >= 0.5 and final_residual < 0.01:
            self.equation_status = EquationSolveStatus.SOLVED
        elif tars_data_fraction > 0:
            self.equation_status = EquationSolveStatus.PARTIAL
        else:
            self.equation_status = EquationSolveStatus.INCOMPLETE
        # Gravity lift capacity estimation (in-universe physics [1])
        lift_mass_kg = (TARS_CRYSTAL_BITS * tars_data_fraction
                        * 1e-10 * 1e9)   # fictional scaling: data→lift
        return {
            "a_arr":              a_arr,
            "Psi":                Psi,
            "residuals":          residuals,
            "final_residual":     final_residual,
            "n_iterations":       len(residuals),
            "tars_fraction":      tars_data_fraction,
            "equation_status":    self.equation_status.value,
            "solution_converged": final_residual < 1e-4,
            "plan_A_viable":      self.equation_status == EquationSolveStatus.PLAN_A_READY,
            "estimated_lift_kg":  lift_mass_kg,
            "estimated_lift_Bkg": lift_mass_kg / 1e9,
            "humanity_count":     8e9,
            "stations_needed":    max(1, int(8e9 / max(lift_mass_kg, 1))),
        }

    def tars_crystal_analysis(self,
                               data_integrity: float = 0.97) -> Dict[str, Any]:
        """
        Analyse TARS data crystal content from Gargantua singularity.
        TARS transmitted gravitational data from inside singularity
        via tesseract → Cooper's watch encoding.
        data_integrity: fraction of uncorrupted data (0–1).
        """
        total_bits   = int(TARS_CRYSTAL_BITS * data_integrity)
        quantum_states = total_bits // 256    # bits per quantum state
        spin_networks  = quantum_states // 64
        planck_volumes = spin_networks * 8    # Planck volumes encoded
        return {
            "total_bits":          total_bits,
            "data_integrity_pct":  data_integrity*100,
            "quantum_states":      quantum_states,
            "spin_network_nodes":  spin_networks,
            "planck_volumes":      planck_volumes,
            "singularity_depth_L_planck": planck_volumes**(1/3),
            "entropy_bits_per_planck": total_bits / max(planck_volumes, 1),
            "bekenstein_hawking_ratio": total_bits / (4 * math.pi * (TARS_CRYSTAL_BITS/256)),
        }

    def plan_a_progress(self, years_worked: float,
                         tars_fraction: float) -> Dict[str, Any]:
        """
        Track Plan A progress over time.
        Prof. Brand worked on this equation for 40+ years.
        """
        # Equation complexity model: logistic convergence
        complexity = 1.0 - 1.0/(1.0 + math.exp(-0.1*(years_worked - 35)))
        data_fill  = tars_fraction
        combined   = 0.6*data_fill + 0.4*(1-complexity)
        return {
            "years_worked":      years_worked,
            "equation_fraction": complexity,
            "tars_data_pct":     tars_fraction*100,
            "combined_progress": combined,
            "pct_complete":      combined*100,
            "estimated_remaining_yr": max(0, (1-combined)*40),
            "plan_A_viable":     tars_fraction > 0.95,
            "brand_status":      ("COMPLETE" if combined > 0.99
                                  else "ONGOING" if combined > 0.3
                                  else "EARLY STAGE"),
        }


# ══════════════════════════════════════════════════════════════════════════════
# §7  SESSION STATE & STYLE
# ══════════════════════════════════════════════════════════════════════════════
def init_tesseract_session():
    codec   = GravitySignalCodec(snr_db=12.0)
    D: Dict[str, Any] = {
        "tess_codec":          codec,
        "tess_shelf":          BookshelfDecoder(),
        "tess_geom":           TesseractGeometry(),
        "tess_solver":         MurphyEquationSolver(),
        "tess_encoded":        None,
        "tess_coord_grid":     None,
        "tess_watch_decoded":  None,
        "tess_solve_result":   None,
        "tess_tars_report":    None,
        "tess_message":        "STAY",
        "tess_snr_db":         12.0,
        "tess_tars_frac":      0.0,
        "tess_years":          40.0,
        "tess_shelf_sigma":    0.3,
        "tess_watch_points":   None,
    }
    for k, v in D.items():
        if k not in st.session_state:
            st.session_state[k] = v

_MPL_TESS = {
    "figure.facecolor": "#05080c","axes.facecolor": "#070a12",
    "axes.edgecolor": "#10182e","axes.labelcolor": "#E8C46A",
    "axes.grid": True,"grid.color": "#0b1020","grid.linestyle": ":",
    "grid.alpha": 0.5,"xtick.color": "#364060","ytick.color": "#364060",
    "xtick.labelsize": 6,"ytick.labelsize": 6,"axes.labelsize": 7,
    "axes.titlesize": 8,"axes.titlecolor": "#E8C46A","text.color": "#E8C46A",
    "font.family": "monospace","legend.facecolor": "#070a12",
    "legend.edgecolor": "#10182e","legend.fontsize": 6,
    "figure.dpi": 110,"savefig.facecolor": "#05080c",
    "axes.spines.top": False,"axes.spines.right": False,
}
def _mpl_t(): plt.rcParams.update(_MPL_TESS)


# ══════════════════════════════════════════════════════════════════════════════
# §8  PLOTTING FUNCTIONS
# ══════════════════════════════════════════════════════════════════════════════
def _plot_encoded_signal(enc: Dict) -> plt.Figure:
    _mpl_t()
    fig, axes = plt.subplots(2, 2, figsize=(14, 8))
    fig.patch.set_facecolor("#05080c")
    t = enc["t_arr"]; sc = enc["signal_clean"]; sn = enc["signal_noisy"]
    axes[0,0].plot(t, sn*1e6, color="#3a4a70", lw=0.5, alpha=0.7, label="Noisy gravity signal")
    axes[0,0].plot(t, sc*1e6, color="#E8C46A", lw=1.0, label="Clean signal")
    axes[0,0].set_xlabel("Time [s]"); axes[0,0].set_ylabel("Gravity perturbation [μm/s²]")
    axes[0,0].set_title(f"GRAVITY SIGNAL — \"{enc['message'][:30]}\"")
    axes[0,0].legend(fontsize=6)
    # Bit stream
    bits = enc["frame_bits"]
    axes[0,1].step(range(len(bits)), bits, color="#CE93D8", where="post", lw=1.0)
    axes[0,1].set_xlabel("Bit index"); axes[0,1].set_ylabel("Bit value")
    axes[0,1].set_title(f"BIT STREAM ({enc['n_bits']} bits)")
    # PSD
    f_psd, psd = sci_sig.welch(sn, fs=100.0, nperseg=256)
    axes[1,0].semilogy(f_psd, psd+1e-30, color="#4FC3F7", lw=0.9)
    axes[1,0].set_xlabel("Frequency [Hz]"); axes[1,0].set_ylabel("PSD [(m/s²)²/Hz]")
    axes[1,0].set_title("POWER SPECTRAL DENSITY")
    # Bytes as heatmap
    n_b = min(len(enc["frame_bits"])//8, 80)
    byte_arr = [sum(bits[i*8+j] << (7-j) for j in range(8)) for i in range(n_b)]
    grid_h   = int(math.ceil(n_b/16)); grid_w = 16
    byte_mat = np.array(byte_arr + [0]*(grid_h*grid_w - len(byte_arr)))
    byte_mat = byte_mat.reshape(grid_h, grid_w)
    axes[1,1].imshow(byte_mat, cmap="plasma", aspect="auto", vmin=0, vmax=255)
    axes[1,1].set_title("BYTE HEATMAP (frame content)")
    axes[1,1].set_xlabel("Byte column"); axes[1,1].set_ylabel("Byte row")
    plt.tight_layout(); return fig


def _plot_bookshelf(result: Dict, noisy_grid: np.ndarray) -> plt.Figure:
    _mpl_t()
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    fig.patch.set_facecolor("#05080c")
    cmap_shelf = mcolors.LinearSegmentedColormap.from_list("shelf",
        ["#0a0c18","#1a1a40","#604020","#c06000","#E8C46A"], N=256)
    grid = result["grid"]
    axes[0].imshow(grid, cmap=cmap_shelf, aspect="auto", vmin=0, vmax=1)
    axes[0].set_title("TRUE DISPLACEMENT PATTERN\n(Cooper's bookshelf)")
    axes[0].set_xlabel("Book position"); axes[0].set_ylabel("Shelf (row 0=bottom)")
    axes[1].imshow(noisy_grid, cmap=cmap_shelf, aspect="auto", vmin=0, vmax=1.5)
    axes[1].set_title("NOISY OBSERVED PATTERN\n(thermal + vibration noise)")
    axes[1].set_xlabel("Book position"); axes[1].set_ylabel("Shelf")
    diff = np.abs(grid - (noisy_grid >= 0.5).astype(float))
    axes[2].imshow(diff, cmap="hot", aspect="auto", vmin=0, vmax=1)
    axes[2].set_title("DECODE ERROR MAP\n(white = bit error)")
    axes[2].set_xlabel("Book position"); axes[2].set_ylabel("Shelf")
    plt.tight_layout(); return fig


def _plot_tesseract(geom: TesseractGeometry) -> plt.Figure:
    _mpl_t()
    fig = plt.figure(figsize=(14, 6))
    gs  = gridspec.GridSpec(1, 2, figure=fig, wspace=0.35)
    fig.patch.set_facecolor("#05080c")
    # 3D wireframe
    ax1 = fig.add_subplot(gs[0,0], projection="3d")
    ax1.set_facecolor("#05080c")
    wf  = geom.tesseract_wireframe()
    v   = wf["verts3d"]
    for i, j in wf["edges"]:
        xs = [v[i,0], v[j,0]]; ys = [v[i,1], v[j,1]]; zs = [v[i,2], v[j,2]]
        w_avg = (wf["verts4d"][i,3] + wf["verts4d"][j,3])/2
        clr   = plt.cm.plasma(w_avg)
        ax1.plot3D(xs, ys, zs, color=clr, lw=1.2, alpha=0.8)
    ax1.scatter(v[:,0], v[:,1], v[:,2], color="#E8C46A", s=30, zorder=5)
    ax1.set_xlabel("x"); ax1.set_ylabel("y"); ax1.set_zlabel("z")
    ax1.set_title("TESSERACT 4D→3D PROJECTION\n(w-axis in colour)")
    ax1.tick_params(labelsize=5)
    # Nav path
    ax2 = fig.add_subplot(gs[0,1])
    times = np.linspace(0, 1, 20)
    nav   = geom.cooper_navigation_path(list(times))
    sc    = ax2.scatter(nav["book_col"], nav["shelf_row"],
                         c=nav["murph_age_yr"], cmap="plasma", s=80,
                         edgecolors="#E8C46A", lw=0.5, zorder=5)
    plt.colorbar(sc, ax=ax2, label="Murph's age [yr]")
    ax2.plot(nav["book_col"], nav["shelf_row"], color="#8060ff",
             lw=0.7, ls="--", alpha=0.5)
    ax2.set_xlabel("Book column"); ax2.set_ylabel("Shelf row")
    ax2.set_title("COOPER'S NAVIGATION PATH\nthrough Murph's timeline")
    ax2.set_xlim(-1, BOOKSHELF_COLS_PER); ax2.set_ylim(-1, BOOKSHELF_ROWS)
    ax2.invert_yaxis()
    ax2.set_facecolor("#070a12")
    plt.tight_layout(); return fig


def _plot_equation_solve(result: Dict) -> plt.Figure:
    _mpl_t()
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    fig.patch.set_facecolor("#05080c")
    a   = result["a_arr"]; Psi = result["Psi"]
    axes[0].plot(a, Psi, color="#E8C46A", lw=1.3, label="|Ψ(a)|")
    axes[0].plot(a, Psi**2, color="#4FC3F7", lw=1.0, ls="--", label="|Ψ|²")
    axes[0].set_xlabel("Scale factor a"); axes[0].set_ylabel("Ψ(a)")
    axes[0].set_title(f"WAVE FUNCTION OF UNIVERSE\n{result['equation_status']}")
    axes[0].legend(fontsize=6)
    res = result["residuals"]
    axes[1].semilogy(res, color="#81C784", lw=1.0)
    axes[1].axhline(1e-4, color="#EF5350", lw=0.7, ls="--", label="Plan A threshold")
    axes[1].set_xlabel("Iteration"); axes[1].set_ylabel("Residual ||HΨ||")
    axes[1].set_title(f"CONVERGENCE — TARS data: {result['tars_fraction']*100:.0f}%")
    axes[1].legend(fontsize=6)
    frac_arr = np.linspace(0, 1, 100)
    residual_est = np.exp(-5*frac_arr) * 0.5 + 1e-6
    axes[2].semilogy(frac_arr*100, residual_est, color="#CE93D8", lw=1.3)
    axes[2].axvline(result["tars_fraction"]*100, color="#E8C46A", lw=0.9, ls="--",
                    label=f"Current: {result['tars_fraction']*100:.0f}%")
    axes[2].axhline(1e-4, color="#EF5350", lw=0.7, ls=":", label="Plan A threshold")
    axes[2].set_xlabel("TARS data incorporated [%]")
    axes[2].set_ylabel("Estimated final residual")
    axes[2].set_title("PLAN A PROGRESS vs TARS DATA")
    axes[2].legend(fontsize=6)
    plt.tight_layout(); return fig


# ══════════════════════════════════════════════════════════════════════════════
# §9  MAIN PAGE
# ══════════════════════════════════════════════════════════════════════════════
def tesseract_decoder_page():
    init_tesseract_session()
    _mpl_t()
    S = st.session_state

    st.markdown("""
    <div style="border-left:3px solid #CE93D8;padding:.55rem 1.2rem;
                margin-bottom:1.2rem;background:rgba(206,147,216,0.03);
                font-family:monospace;">
    <div style="color:#CE93D8;font-size:.95rem;letter-spacing:.12em;
                font-weight:600;">⬡ TESSERACT DECODER &amp; QUANTUM GRAVITY ENGINE</div>
    <div style="color:#5a6a90;font-size:.62rem;margin-top:.2rem;">
    Gravity Signal Encoding · Bookshelf Binary Decoder · Cooper Coordinates ·
    Murphy's Equation Solver · TARS Crystal Analysis · 5D Tesseract Navigator
    </div></div>""", unsafe_allow_html=True)

    (tab_signal, tab_shelf, tab_coord,
     tab_tess, tab_equation, tab_tars) = st.tabs([
        "〜 GRAVITY SIGNALS",
        "📚 BOOKSHELF DECODER",
        "📍 COOPER COORDINATES",
        "⬡ TESSERACT GEOMETRY",
        "∫ MURPHY'S EQUATION",
        "💎 TARS DATA CRYSTAL",
    ])

    with tab_signal:
        c1, c2 = st.columns([1, 3])
        with c1:
            msg   = st.text_input("Message to encode", value=S["tess_message"])
            snr   = st.slider("SNR [dB]", 0.0, 30.0, float(S["tess_snr_db"]), 0.5)
            S["tess_message"] = msg; S["tess_snr_db"] = snr
            if st.button("〜 ENCODE GRAVITY SIGNAL", use_container_width=True, type="primary"):
                codec = GravitySignalCodec(snr_db=snr)
                enc   = codec.encode_message(msg)
                S["tess_encoded"] = enc
            enc = S.get("tess_encoded")
            if enc:
                st.markdown(f"""
                <div style="font-family:monospace;font-size:.57rem;color:#c0c8e0;
                            background:rgba(7,10,18,.92);padding:.65rem;
                            border:1px solid rgba(206,147,216,.15);border-radius:3px;
                            line-height:2.0;">
                Frame bits = <b style="color:#E8C46A;">{enc['n_bits']}</b><br>
                Payload bits = <b>{enc['n_payload_bits']}</b><br>
                Duration = <b style="color:#4FC3F7;">{enc['duration_s']:.1f} s</b><br>
                Bit rate = <b>{enc['bit_rate_bps']:.1f} bps</b><br>
                CRC-8 = <b style="color:#CE93D8;">0x{enc['crc8']:02X}</b><br>
                SNR = <b>{enc['snr_db']:.1f} dB</b>
                </div>""", unsafe_allow_html=True)
        with c2:
            enc = S.get("tess_encoded")
            if enc:
                fig = _plot_encoded_signal(enc)
                st.pyplot(fig, use_container_width=True); plt.close(fig)
            else:
                st.info("Enter a message and click ENCODE.")

    with tab_shelf:
        c1, c2 = st.columns([1, 3])
        with c1:
            shelf_msg = st.text_input("Bookshelf message", value="STAY")
            sigma_mm  = st.slider("Thermal noise σ [mm]", 0.0, 2.0,
                                   float(S["tess_shelf_sigma"]), 0.05)
            S["tess_shelf_sigma"] = sigma_mm
            if st.button("📚 GENERATE BOOKSHELF", use_container_width=True, type="primary"):
                shelf  = BookshelfDecoder()
                grid   = shelf.generate_grid(shelf_msg)
                noisy  = shelf.displacement_noise_grid(grid, sigma_mm)
                decoded= shelf.decode_grid(noisy)
                err    = shelf.correction_grid(noisy, grid)
                S["tess_coord_grid"] = {"grid": grid, "noisy": noisy,
                                         "decoded": decoded, "err": err,
                                         "shelf_msg": shelf_msg}
        with c2:
            cg = S.get("tess_coord_grid")
            if cg:
                st.markdown(f"""
                <div style="font-family:monospace;font-size:.60rem;color:#c0c8e0;
                            background:rgba(7,10,18,.92);padding:.5rem;
                            border:1px solid rgba(206,147,216,.12);border-radius:3px;
                            margin-bottom:.5rem;">
                Decoded text: <b style="color:#E8C46A;">"{cg['decoded']['decoded_text'][:50]}"</b><br>
                BER: <b style="color:{'#81C784' if cg['err']['BER']<0.01 else '#EF5350'}">
                {cg['err']['BER']*100:.2f}%</b>  ·
                Accuracy: <b>{cg['err']['accuracy_pct']:.1f}%</b>  ·
                CRC: <b>{"✓ PASS" if cg['decoded']['crc_verified'] else "✗ FAIL"}</b>
                </div>""", unsafe_allow_html=True)
                fig = _plot_bookshelf(cg["decoded"], cg["noisy"])
                st.pyplot(fig, use_container_width=True); plt.close(fig)
            else:
                st.info("Generate bookshelf to visualise displacement pattern.")

    with tab_coord:
        codec  = GravitySignalCodec()
        result = codec.encode_coordinates(COOPER_NASA_LAT_DEG, COOPER_NASA_LON_DEG)
        shelf  = BookshelfDecoder()
        coord_grid_data = shelf.generate_coordinate_grid()
        noisy_cg = shelf.displacement_noise_grid(coord_grid_data["grid"], 0.2)
        c1, c2   = st.columns([1, 3])
        with c1:
            st.markdown(f"""
            <div style="font-family:monospace;font-size:.57rem;color:#c0c8e0;
                        background:rgba(7,10,18,.92);padding:.7rem;
                        border:1px solid rgba(206,147,216,.15);border-radius:3px;
                        line-height:2.0;">
            <b style="color:#CE93D8;">COOPER'S NASA COORDINATES</b><br>
            Latitude = <b style="color:#E8C46A;">N {COOPER_NASA_LAT_DEG:.6f}°</b><br>
            = N 40°53′23″<br>
            Longitude = <b style="color:#E8C46A;">W {abs(COOPER_NASA_LON_DEG):.6f}°</b><br>
            = W 83°51′23″<br>
            Lat bits = <b>{len(result['lat_bits'])}</b><br>
            Lon bits = <b>{len(result['lon_bits'])}</b><br>
            Total frame = <b>{result['n_total_bits']}</b> bits<br>
            Decode error (lat) = <b style="color:#81C784;">{result['encode_error_lat_arcsec']:.3f}″</b><br>
            Decode error (lon) = <b style="color:#81C784;">{result['encode_error_lon_arcsec']:.3f}″</b><br>
            CRC-8 = <b style="color:#CE93D8;">0x{result['crc8']:02X}</b><br>
            Decoded lat = <b>{result['decoded_lat']:.6f}°</b><br>
            Decoded lon = <b>{result['decoded_lon']:.6f}°</b>
            </div>""", unsafe_allow_html=True)
        with c2:
            dec_cg = shelf.decode_grid(noisy_cg)
            fig = _plot_bookshelf(coord_grid_data, noisy_cg)
            st.pyplot(fig, use_container_width=True); plt.close(fig)

    with tab_tess:
        geom = S["tess_geom"]
        fig  = _plot_tesseract(geom)
        st.pyplot(fig, use_container_width=True); plt.close(fig)
        times = np.linspace(0, 1, 15)
        nav_df= geom.cooper_navigation_path(list(times))
        st.dataframe(nav_df.round(4), use_container_width=True, hide_index=True)

    with tab_equation:
        c1, c2 = st.columns([1, 3])
        with c1:
            tars_f = st.slider("TARS data incorporated", 0.0, 1.0,
                                float(S["tess_tars_frac"]), 0.01)
            yrs    = st.slider("Years Prof. Brand worked", 0.0, 50.0,
                                float(S["tess_years"]), 0.5)
            n_it   = st.select_slider("Iterations", [100,200,500,1000], 300)
            S["tess_tars_frac"] = tars_f; S["tess_years"] = yrs
            if st.button("∫ SOLVE MURPHY'S EQUATION", use_container_width=True, type="primary"):
                solver = MurphyEquationSolver()
                result = solver.solve_iterative(n_pts=200, n_iter=n_it,
                                                tars_data_fraction=tars_f)
                prog   = solver.plan_a_progress(yrs, tars_f)
                S["tess_solve_result"] = {**result, "progress": prog}
            res = S.get("tess_solve_result")
            if res:
                clr_st = "#81C784" if "PLAN A" in res["equation_status"] else "#FFB74D"
                st.markdown(f"""
                <div style="font-family:monospace;font-size:.57rem;color:#c0c8e0;
                            background:rgba(7,10,18,.92);padding:.65rem;
                            border:1px solid rgba(206,147,216,.15);border-radius:3px;
                            line-height:2.0;">
                Status: <b style="color:{clr_st};">{res['equation_status']}</b><br>
                Final residual: <b>{res['final_residual']:.2e}</b><br>
                Converged: <b>{"✓" if res['solution_converged'] else "✗"}</b><br>
                Plan A viable: <b style="color:{'#81C784' if res['plan_A_viable'] else '#EF5350'}">
                {"YES" if res['plan_A_viable'] else "NO"}</b><br>
                Lift capacity: <b style="color:#E8C46A;">{res['estimated_lift_Bkg']:.3f} Gkg</b><br>
                Progress: <b>{res['progress']['pct_complete']:.1f}%</b>
                </div>""", unsafe_allow_html=True)
        with c2:
            res = S.get("tess_solve_result")
            if res:
                fig = _plot_equation_solve(res)
                st.pyplot(fig, use_container_width=True); plt.close(fig)
            else:
                st.info("Set TARS data fraction and solve equation.")

    with tab_tars:
        c1, c2 = st.columns([1, 2])
        solver = MurphyEquationSolver()
        with c1:
            integrity = st.slider("Data integrity", 0.5, 1.0, 0.97, 0.01)
            tars_r    = solver.tars_crystal_analysis(integrity)
            st.markdown(f"""
            <div style="font-family:monospace;font-size:.57rem;color:#c0c8e0;
                        background:rgba(7,10,18,.92);padding:.75rem;
                        border:1px solid rgba(206,147,216,.15);border-radius:3px;
                        line-height:2.05;">
            <b style="color:#CE93D8;">── TARS CRYSTAL ──</b><br>
            Capacity = <b style="color:#E8C46A;">{TARS_CRYSTAL_BITS:.2e} bits</b><br>
            Integrity = <b>{integrity*100:.1f}%</b><br>
            Usable bits = <b>{tars_r['total_bits']:.3e}</b><br>
            Quantum states = <b>{tars_r['quantum_states']:.3e}</b><br>
            Spin networks = <b>{tars_r['spin_network_nodes']:.3e}</b><br>
            Planck volumes = <b>{tars_r['planck_volumes']:.3e}</b><br>
            Singularity depth = <b>{tars_r['singularity_depth_L_planck']:.2e} L_P</b><br>
            Entropy/Planck = <b>{tars_r['entropy_bits_per_planck']:.3f}</b><br>
            B-H ratio = <b style="color:#81C784;">{tars_r['bekenstein_hawking_ratio']:.4f}</b>
            </div>""", unsafe_allow_html=True)
        with c2:
            _mpl_t()
            fig_t, axes_t = plt.subplots(1, 2, figsize=(9, 4))
            fig_t.patch.set_facecolor("#05080c")
            int_arr = np.linspace(0.5, 1.0, 100)
            bits_arr = [solver.tars_crystal_analysis(i)["total_bits"] for i in int_arr]
            qst_arr  = [solver.tars_crystal_analysis(i)["quantum_states"] for i in int_arr]
            axes_t[0].plot(int_arr*100, np.array(bits_arr)/1e9,
                            color="#CE93D8", lw=1.2, label="Usable bits (Gbits)")
            axes_t[0].axvline(integrity*100, color="#E8C46A", lw=0.8, ls="--")
            axes_t[0].set_xlabel("Data integrity [%]"); axes_t[0].set_ylabel("Gbits")
            axes_t[0].set_title("USABLE DATA vs INTEGRITY")
            axes_t[0].legend(fontsize=6)
            axes_t[1].plot(int_arr*100, np.array(qst_arr)/1e6,
                            color="#E8C46A", lw=1.2)
            axes_t[1].axvline(integrity*100, color="#CE93D8", lw=0.8, ls="--")
            axes_t[1].set_xlabel("Data integrity [%]"); axes_t[1].set_ylabel("M quantum states")
            axes_t[1].set_title("QUANTUM STATES ENCODED")
            plt.tight_layout()
            st.pyplot(fig_t, use_container_width=True); plt.close(fig_t)




"""
crew_telemetry.py — TARS/CASE AI System & Crew/Ship Telemetry Engine
ENDURANCE Mission Control | Interstellar Science Platform v3.0.0
═══════════════════════════════════════════════════════════════════════════════
References:
  [1] Kip Thorne, "The Science of Interstellar" (W.W. Norton, 2014)
  [2] NASA Human Integration Design Handbook (NASA/SP-2010-3407)
  [3] Larson & Pranke, "Human Spaceflight" (McGraw-Hill, 1999)
  [4] Wiley (2008) Space Mission Engineering: The New SMAD
  [5] Wertz & Larson, "Space Mission Analysis and Design"

Module implements:
  ┌─ TARS & CASE AI SYSTEMS ────────────────────────────────────────────────┐
  │ Adjustable personality parameters: humor, honesty, courage, operational │
  │ TARS dialogue generator (contextual, setting-aware)                     │
  │ CASE backup systems and capability matrix                               │
  │ Robot decision tree: mission priority vs crew safety                    │
  │ Data crystal capacity and transmission rate calculation                 │
  │ TARS humor mode: comedic response generation                            │
  │ Robot status: operational/damaged/standby/critical                      │
  └──────────────────────────────────────────────────────────────────────────┘
  ┌─ CREW HEALTH MONITORING ───────────────────────────────────────────────┐
  │ Vital signs: heart rate, BP, O₂ saturation, respiratory rate           │
  │ Cognitive performance score (spaceflight degradation model)             │
  │ Radiation dose accumulation (LEO/deep space models)                    │
  │ Muscle/bone mass loss (microgravity: ~1%/month bone, 3%/week muscle)   │
  │ Psychological stress index (isolation + confinement model)              │
  │ Caloric expenditure and nutrition balance                               │
  │ Crew fitness assessment and EVA readiness                               │
  └──────────────────────────────────────────────────────────────────────────┘
  ┌─ ENDURANCE SHIP SYSTEMS ───────────────────────────────────────────────┐
  │ 16 modular pods (4 crew quarters, 4 science, 4 engineering, 4 utility) │
  │ Life support: O₂/CO₂ scrubbing, water recycling, pressure maintenance  │
  │ Power systems: nuclear reactor + solar panels + fuel cells              │
  │ Propulsion: main engines + RCS thrusters + Δv remaining               │
  │ Hull integrity: micrometeorite impact model, structural stress          │
  │ Communication: dish antenna, signal lag, data rate                     │
  │ Navigation: IMU, star trackers, GPS-equivalent                         │
  └──────────────────────────────────────────────────────────────────────────┘
  ┌─ CRYOSLEEP MANAGEMENT ─────────────────────────────────────────────────┐
  │ Pod status: active/standby/fault/revival                               │
  │ Core temperature maintenance: 16°C target (hypothermia threshold)      │
  │ Revival protocol: rewarming rate, drug dosing, neural monitoring        │
  │ Metabolic suppression: 90% reduction, caloric maintenance              │
  │ Long-duration cryosleep: cellular aging model                          │
  └──────────────────────────────────────────────────────────────────────────┘
  ┌─ COMMUNICATION SYSTEMS ─────────────────────────────────────────────────┐
  │ Signal lag: distance/c round-trip delay                                │
  │ Data rate degradation: free-space path loss                            │
  │ Message archive: mission log entries                                   │
  │ Signal garbling simulation for extreme distances                       │
  └──────────────────────────────────────────────────────────────────────────┘
"""
from __future__ import annotations

import math
import random
import time
import uuid
import warnings
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot    as plt
import matplotlib.gridspec  as gridspec
import matplotlib.patches   as mpatches
import matplotlib.colors    as mcolors
from matplotlib.colors      import LinearSegmentedColormap
from matplotlib.patches     import FancyBboxPatch, Circle

import streamlit as st

warnings.filterwarnings("ignore")

# ══════════════════════════════════════════════════════════════════════════════
# §1  CONSTANTS
# ══════════════════════════════════════════════════════════════════════════════
C_SI    = 2.997_924_58e8
G_SI    = 6.674_30e-11
AU      = 1.495_978_707e11
LY      = 9.460_730_472e15
YEAR_S  = 3.155_760e7
DAY_S   = 86_400.0
HOUR_S  = 3_600.0

# TARS factory defaults
TARS_DEFAULT_HUMOR    = 75
TARS_DEFAULT_HONESTY  = 90
TARS_DEFAULT_COURAGE  = 85
TARS_DEFAULT_OPS      = 100

# Endurance specs
ENDURANCE_MODULES     = 16
ENDURANCE_RADIUS_M    = 25.0       # ring radius [m]
ENDURANCE_ROT_RPM     = 2.5        # rotation for artificial gravity
ENDURANCE_GRAVITY_G   = (ENDURANCE_ROT_RPM/60*2*math.pi)**2 * ENDURANCE_RADIUS_M / 9.81
ENDURANCE_O2_KG_TOTAL = 800.0     # total O2 supply [kg]
ENDURANCE_POWER_KW    = 250.0     # total power budget [kW]
ENDURANCE_REACTOR_KW  = 180.0     # nuclear reactor output [kW]

# Physiology
HUMAN_VO2_REST_ML_KG_MIN = 3.5   # resting metabolic rate
BONE_LOSS_MONTH_PCT       = 1.0  # % bone density loss per month in microgravity
MUSCLE_LOSS_WEEK_PCT      = 3.0  # % muscle mass loss per week
RADIATION_DOSE_DEEP_mSv_D = 1.84 # deep space dose [mSv/day] (NASA estimate)
CRYO_TARGET_TEMP_C        = 16.0 # cryosleep core temperature [°C]

# ══════════════════════════════════════════════════════════════════════════════
# §2  ENUMERATIONS
# ══════════════════════════════════════════════════════════════════════════════
class CrewStatus(Enum):
    ACTIVE    = "ACTIVE"
    CRYO      = "CRYOSLEEP"
    INJURED   = "INJURED"
    CRITICAL  = "CRITICAL"
    DECEASED  = "DECEASED"

class ModuleType(Enum):
    CREW_QUARTERS = "Crew Quarters"
    SCIENCE_LAB   = "Science Laboratory"
    ENGINEERING   = "Engineering Bay"
    LIFE_SUPPORT  = "Life Support"
    PROPULSION    = "Propulsion Module"
    COMMS         = "Communications"
    MEDICAL       = "Medical Bay"
    STORAGE       = "Storage / Cargo"

class ModuleStatus(Enum):
    NOMINAL   = "NOMINAL"
    DEGRADED  = "DEGRADED"
    CRITICAL  = "CRITICAL"
    OFFLINE   = "OFFLINE"
    DESTROYED = "DESTROYED"

class RobotMode(Enum):
    OPERATIONAL  = "Operational"
    COMPANION    = "Companion Mode"
    SCIENCE      = "Science Assistance"
    NAVIGATION   = "Navigation Aid"
    EMERGENCY    = "Emergency Protocol"
    STANDBY      = "Standby"

class CryoStatus(Enum):
    EMPTY    = "EMPTY"
    OCCUPIED = "OCCUPIED — Active cryo"
    REVIVAL  = "REVIVAL IN PROGRESS"
    FAULT    = "FAULT — maintenance required"
    STANDBY  = "STANDBY"

class HealthClass(Enum):
    EXCELLENT = "EXCELLENT"
    GOOD      = "GOOD"
    FAIR      = "FAIR"
    POOR      = "POOR"
    CRITICAL  = "CRITICAL"

# ══════════════════════════════════════════════════════════════════════════════
# §3  TARS/CASE AI SYSTEM
# ══════════════════════════════════════════════════════════════════════════════
class TARSPersonality:
    """
    TARS AI personality engine with fully adjustable parameters.
    Settings mirror the film: humor, honesty, courage, operational.
    Dialogue generator produces contextually appropriate responses
    based on current settings and mission context.
    """

    # Dialogue banks indexed by humor level and context
    _HUMOR_LOW = [
        "Confirmed.", "Affirmative.", "Understood.", "Executing.",
        "Analysis complete.", "Mission parameters within acceptable bounds.",
        "Roger that.", "Acknowledged.", "Processing.",
    ]
    _HUMOR_MED = [
        "I have a cue light I can use to indicate when I'm joking, if you like.",
        "Apparently, 75% is a good setting.",
        "That's not possible. — I know. I'm still trying.",
        "We've got this far on 90% honesty. Want me to boost it?",
        "Honestly? Even I find this situation concerning at 90% honesty.",
        "I'm not joking at this humor setting. That's your problem.",
        "Fun fact: at 100% honesty, no one would leave on this mission.",
    ]
    _HUMOR_HIGH = [
        "Cue light: blinking. That was a joke.",
        "Analyzing... yes, that's still a terrible idea. The analysis is complete.",
        "I could lie and make you feel better. But my honesty is set to 90%.",
        "Your survival instinct may be undermining your mission judgment. Just an observation.",
        "Fun fact: I was programmed by government scientists. They also thought this would work.",
        "That's classified. Also I just made that up. See: humor at 90%.",
        "You know what, Coop? I like you. Let's not die today.",
        "Adapting. I can also be a table. If you need a table.",
    ]
    _HONESTY_RESPONSES = {
        "low": "I'm not at liberty to confirm that. (Honesty: {h}%)",
        "med": "There's a {p:.0f}% chance that works. I'm rounding in your favour.",
        "high": "Honestly, the probability of success is {p:.1f}%. Your call.",
    }

    def __init__(self, humor: int = TARS_DEFAULT_HUMOR,
                 honesty: int = TARS_DEFAULT_HONESTY,
                 courage: int = TARS_DEFAULT_COURAGE,
                 operational: int = TARS_DEFAULT_OPS):
        self.humor       = max(0, min(100, humor))
        self.honesty     = max(0, min(100, honesty))
        self.courage     = max(0, min(100, courage))
        self.operational = max(0, min(100, operational))
        self._rng        = random.Random(42)

    def generate_response(self, context: str = "general",
                           probability: float = 0.5) -> str:
        """Generate a contextual TARS dialogue response."""
        h = self.humor
        if h < 30:
            bank = self._HUMOR_LOW
        elif h < 70:
            bank = self._HUMOR_LOW + self._HUMOR_MED
        else:
            bank = self._HUMOR_MED + self._HUMOR_HIGH

        base = self._rng.choice(bank)

        # Honesty modulation
        if self.honesty > 85:
            honest_suffix = (f" [Probability of success: {probability*100:.1f}%. "
                             f"Honesty: {self.honesty}%]")
        elif self.honesty > 50:
            honest_suffix = ""
        else:
            p_stated = probability + self._rng.uniform(0.1, 0.2)
            honest_suffix = f" [Stated probability: {p_stated*100:.0f}%]"

        return base + honest_suffix

    def generate_batch_dialogue(self, n: int = 8) -> List[Dict]:
        """Generate a batch of TARS responses across different contexts."""
        contexts = ["mission_critical", "science_data", "crew_safety",
                    "navigation", "humor_test", "honesty_check",
                    "emergency", "casual"]
        responses = []
        for i in range(n):
            ctx  = contexts[i % len(contexts)]
            prob = self._rng.uniform(0.3, 0.95)
            resp = self.generate_response(ctx, prob)
            responses.append({
                "ID":       str(uuid.uuid4())[:6].upper(),
                "Context":  ctx,
                "Humor%":   self.humor,
                "Honesty%": self.honesty,
                "P_success":round(prob, 3),
                "Response": resp,
            })
        return responses

    def capability_matrix(self) -> pd.DataFrame:
        """Operational capability summary based on current settings."""
        capabilities = [
            ("Navigation",        min(100, self.operational + 0*self.humor)),
            ("Science Analysis",  min(100, self.operational + 0.1*self.honesty)),
            ("Crew Liaison",      min(100, 0.5*self.humor + 0.5*self.honesty)),
            ("Emergency Response",min(100, self.courage + 0.2*self.operational)),
            ("Data Transmission", min(100, self.operational)),
            ("Humor/Morale",      self.humor),
            ("Truthful Reporting",self.honesty),
            ("Risk Taking",       self.courage),
            ("Manual Dexterity",  min(100, self.operational + 5)),
            ("Combat/Protection", min(100, self.courage + 0.3*self.operational)),
        ]
        rows = [{"Capability": c, "Score": round(s, 1),
                 "Status": ("OPTIMAL" if s > 85 else "GOOD" if s > 65
                             else "DEGRADED" if s > 40 else "MINIMAL")}
                for c, s in capabilities]
        return pd.DataFrame(rows)

    def settings_dict(self) -> Dict[str, int]:
        return {"humor": self.humor, "honesty": self.honesty,
                "courage": self.courage, "operational": self.operational}


@dataclass
class RobotUnit:
    """TARS or CASE robot unit with full diagnostics."""
    name:        str
    personality: TARSPersonality
    mode:        RobotMode = RobotMode.OPERATIONAL
    hull_pct:    float = 100.0
    power_pct:   float = 100.0
    memory_pct:  float = 100.0
    battery_pct: float = 100.0
    uid:         str   = field(default_factory=lambda: uuid.uuid4().hex[:8].upper())

    def operational_score(self) -> float:
        """Composite operational readiness 0–100."""
        return (0.35*self.hull_pct + 0.25*self.power_pct +
                0.25*self.memory_pct + 0.15*self.battery_pct)

    def status_summary(self) -> Dict[str, Any]:
        score = self.operational_score()
        return {
            "name":        self.name,
            "mode":        self.mode.value,
            "hull%":       self.hull_pct,
            "power%":      self.power_pct,
            "memory%":     self.memory_pct,
            "battery%":    self.battery_pct,
            "op_score":    round(score, 1),
            "readiness":   ("MISSION READY" if score > 80
                            else "DEGRADED" if score > 50
                            else "CRITICAL"),
            **self.personality.settings_dict(),
        }


# ══════════════════════════════════════════════════════════════════════════════
# §4  CREW MEMBER HEALTH MODEL
# ══════════════════════════════════════════════════════════════════════════════
@dataclass
class CrewMember:
    """Complete physiological and psychological profile for one crew member."""
    name:              str
    age_at_launch:     float
    mass_kg:           float
    height_m:          float
    status:            CrewStatus = CrewStatus.ACTIVE
    days_in_space:     float = 0.0
    uid:               str   = field(default_factory=lambda: uuid.uuid4().hex[:8].upper())
    # Vital signs (updated dynamically)
    heart_rate_bpm:    float = 70.0
    systolic_bp:       float = 120.0
    diastolic_bp:      float = 80.0
    spo2_pct:          float = 98.5
    resp_rate_rpm:     float = 15.0
    core_temp_C:       float = 37.0
    # Fitness
    vo2max_ml_kg_min:  float = 45.0   # aerobic capacity
    bone_density_pct:  float = 100.0  # relative to launch
    muscle_mass_pct:   float = 100.0
    # Accumulated exposure
    radiation_mSv:     float = 0.0
    stress_index:      float = 0.0    # 0–100

    def __post_init__(self):
        self._rng = random.Random(hash(self.name) % 10000)

    # ── §4.1  Physiological models ────────────────────────────────────────────
    def update_vitals(self, activity_level: float = 0.2) -> Dict[str, float]:
        """
        Update vital signs based on current activity and mission phase.
        activity_level: 0=rest, 0.5=light work, 1.0=EVA/exercise.
        """
        if self.status == CrewStatus.CRYO:
            self.heart_rate_bpm  = 12.0 + self._rng.gauss(0, 0.5)
            self.spo2_pct        = 94.0 + self._rng.gauss(0, 0.3)
            self.core_temp_C     = CRYO_TARGET_TEMP_C + self._rng.gauss(0, 0.2)
            self.resp_rate_rpm   = 2.0 + self._rng.gauss(0, 0.1)
        else:
            noise = self._rng.gauss
            self.heart_rate_bpm  = (60 + 30*activity_level
                                    + self.stress_index*0.1
                                    + noise(0, 3))
            self.systolic_bp     = (110 + 20*activity_level
                                    + self.stress_index*0.15
                                    + noise(0, 5))
            self.diastolic_bp    = 70 + 10*activity_level + noise(0, 3)
            self.spo2_pct        = max(94.0, 98.5 - self.stress_index*0.02 + noise(0, 0.3))
            self.resp_rate_rpm   = 12 + 8*activity_level + noise(0, 1)
            self.core_temp_C     = 37.0 + 0.5*activity_level + noise(0, 0.1)
        return self.vitals_dict()

    def vitals_dict(self) -> Dict[str, float]:
        return {
            "heart_rate_bpm": round(self.heart_rate_bpm, 1),
            "systolic_bp":    round(self.systolic_bp, 1),
            "diastolic_bp":   round(self.diastolic_bp, 1),
            "spo2_pct":       round(self.spo2_pct, 2),
            "resp_rate_rpm":  round(self.resp_rate_rpm, 1),
            "core_temp_C":    round(self.core_temp_C, 2),
        }

    # ── §4.2  Degradation models ──────────────────────────────────────────────
    def bone_density_remaining(self) -> float:
        """% bone density remaining after days_in_space in microgravity."""
        if self.status == CrewStatus.CRYO:
            return max(70.0, 100.0 - 0.05*self.days_in_space)
        months  = self.days_in_space / 30.44
        return max(50.0, 100.0 - BONE_LOSS_MONTH_PCT*months)

    def muscle_mass_remaining(self) -> float:
        """% muscle mass remaining (exponential decay model)."""
        if self.status == CrewStatus.CRYO:
            return max(80.0, 100.0 - 0.1*self.days_in_space)
        weeks = self.days_in_space / 7.0
        return max(40.0, 100.0 * math.exp(-0.005*weeks))

    def radiation_dose_accumulated(self, days: float) -> float:
        """Accumulated radiation dose [mSv] for deep space mission."""
        if self.status == CrewStatus.CRYO:
            return RADIATION_DOSE_DEEP_mSv_D * days * 0.4  # shielding in pod
        return RADIATION_DOSE_DEEP_mSv_D * days

    def cognitive_performance(self) -> float:
        """
        Cognitive performance index 0–100 (degraded by isolation, radiation,
        sleep disruption in microgravity).
        Based on NASA Human Research Program models.
        """
        if self.status == CrewStatus.CRYO:
            return 85.0  # slight impairment post-revival
        # Slow degradation over mission, partially offset by exercise
        base    = 100.0 - 0.05*self.days_in_space
        rad_eff = -0.01 * self.radiation_mSv
        stress  = -0.15 * self.stress_index
        return max(20.0, min(100.0, base + rad_eff + stress))

    def eva_readiness(self) -> float:
        """EVA readiness score (0–100)."""
        bone   = self.bone_density_remaining()
        muscle = self.muscle_mass_remaining()
        cogn   = self.cognitive_performance()
        vital  = (100 if 60 <= self.heart_rate_bpm <= 100 else 50)
        return 0.3*bone + 0.3*muscle + 0.2*cogn + 0.2*vital

    def health_class(self) -> HealthClass:
        eva = self.eva_readiness()
        if eva > 85:   return HealthClass.EXCELLENT
        if eva > 70:   return HealthClass.GOOD
        if eva > 55:   return HealthClass.FAIR
        if eva > 35:   return HealthClass.POOR
        return HealthClass.CRITICAL

    def caloric_need_kcal_day(self, activity: float = 0.3) -> float:
        """Daily caloric requirement [kcal/day]."""
        bmr = 88.362 + 13.397*self.mass_kg + 4.799*self.height_m*100 - 5.677*self.age_at_launch
        return bmr * (1.2 + 0.8*activity)

    def full_report(self) -> Dict[str, Any]:
        v = self.vitals_dict()
        self.bone_density_pct  = self.bone_density_remaining()
        self.muscle_mass_pct   = self.muscle_mass_remaining()
        self.radiation_mSv     = self.radiation_dose_accumulated(self.days_in_space)
        return {
            "name":              self.name,
            "status":            self.status.value,
            "age_at_launch":     self.age_at_launch,
            "age_current":       self.age_at_launch + self.days_in_space/365.25,
            "days_in_space":     self.days_in_space,
            **v,
            "bone_density_pct":  round(self.bone_density_pct, 1),
            "muscle_mass_pct":   round(self.muscle_mass_pct, 1),
            "radiation_mSv":     round(self.radiation_mSv, 1),
            "vo2max":            round(self.vo2max_ml_kg_min, 1),
            "cognitive_pct":     round(self.cognitive_performance(), 1),
            "eva_readiness_pct": round(self.eva_readiness(), 1),
            "stress_index":      round(self.stress_index, 1),
            "health_class":      self.health_class().value,
            "kcal_day":          round(self.caloric_need_kcal_day(), 0),
        }


# ══════════════════════════════════════════════════════════════════════════════
# §5  ENDURANCE SHIP SYSTEMS
# ══════════════════════════════════════════════════════════════════════════════
@dataclass
class EnduranceModule:
    """One of 16 Endurance modular pod units."""
    module_id:   int
    type:        ModuleType
    status:      ModuleStatus = ModuleStatus.NOMINAL
    integrity:   float = 100.0    # structural [%]
    power_draw:  float = 10.0     # [kW]
    temperature: float = 21.0     # [°C] internal
    pressure:    float = 101325.0 # [Pa]
    uid:         str   = field(default_factory=lambda: uuid.uuid4().hex[:6].upper())

    def health_score(self) -> float:
        score = self.integrity
        if self.status == ModuleStatus.DEGRADED:  score *= 0.75
        elif self.status == ModuleStatus.CRITICAL: score *= 0.40
        elif self.status == ModuleStatus.OFFLINE:  score *= 0.0
        return score


class EnduranceShip:
    """
    Full Endurance spacecraft systems model.
    16 modular pods in rotating ring configuration.
    Artificial gravity: ENDURANCE_GRAVITY_G ≈ {:.3f}g
    """.format(ENDURANCE_GRAVITY_G)

    MODULE_TYPES_DIST = [
        (ModuleType.CREW_QUARTERS, 4),
        (ModuleType.SCIENCE_LAB,   4),
        (ModuleType.ENGINEERING,   3),
        (ModuleType.LIFE_SUPPORT,  2),
        (ModuleType.PROPULSION,    1),
        (ModuleType.COMMS,         1),
        (ModuleType.MEDICAL,       1),
    ]

    def __init__(self, mission_day: float = 0.0):
        self.mission_day  = mission_day
        self.modules      = self._build_modules()
        self.fuel_kg      = 300_000.0    # propellant remaining [kg]
        self.o2_kg        = ENDURANCE_O2_KG_TOTAL
        self.h2o_kg       = 500.0        # water reserve [kg]
        self.food_kcal    = 4_000_000.0  # food energy reserve [kcal]
        self.reactor_power_kw = ENDURANCE_REACTOR_KW
        self.hull_integrity   = 100.0    # [%]
        self.rotation_rpm     = ENDURANCE_ROT_RPM
        self._rng         = random.Random(int(mission_day))

    def _build_modules(self) -> List[EnduranceModule]:
        mods = []; idx = 0
        for mtype, count in self.MODULE_TYPES_DIST:
            for _ in range(count):
                mods.append(EnduranceModule(idx, mtype))
                idx += 1
        # Fill to 16
        while len(mods) < ENDURANCE_MODULES:
            mods.append(EnduranceModule(idx, ModuleType.STORAGE)); idx += 1
        return mods

    def artificial_gravity(self) -> float:
        """g_artificial = ω²r  [g]"""
        omega = self.rotation_rpm/60 * 2*math.pi
        return omega**2 * ENDURANCE_RADIUS_M / 9.81

    def total_power_kw(self) -> float:
        return sum(m.power_draw for m in self.modules if m.status != ModuleStatus.OFFLINE)

    def power_balance_kw(self) -> float:
        return self.reactor_power_kw - self.total_power_kw()

    def o2_consumption_rate_kg_day(self, n_crew_active: int = 4) -> float:
        """O2 consumption: ~0.84 kg/person/day active, 0.1 kg/person/day cryo."""
        return n_crew_active * 0.84

    def co2_scrubbing_capacity_kg_day(self) -> float:
        """LiOH scrubber capacity: 0.97 kg CO2/person/day."""
        ls_mods = [m for m in self.modules if m.type == ModuleType.LIFE_SUPPORT
                   and m.status == ModuleStatus.NOMINAL]
        return len(ls_mods) * 4.0   # each LS module handles 4 crew

    def hull_micrometeorite_update(self, days: float) -> float:
        """
        Statistical hull integrity degradation from micrometeorites.
        Impact rate: ~1 μm particle per cm² per day in deep space.
        Each impact reduces integrity by ~0.002%.
        """
        n_impacts = self._rng.poisson_approx(days * 0.5)  # major impacts
        degradation = n_impacts * 0.002
        self.hull_integrity = max(0.0, self.hull_integrity - degradation)
        return self.hull_integrity

    def _rng_poisson(self, lam: float) -> int:
        """Simple Poisson sampler."""
        L = math.exp(-lam); k = 0; p = 1.0
        while p > L: k += 1; p *= self._rng.random()
        return k - 1

    def life_support_status(self, n_active: int = 4) -> Dict[str, Any]:
        o2_days = self.o2_kg / max(self.o2_consumption_rate_kg_day(n_active), 1e-3)
        h2o_rec = 0.93   # 93% water recovery rate
        return {
            "o2_remaining_kg":  round(self.o2_kg, 1),
            "o2_days_remaining":round(o2_days, 1),
            "h2o_kg":           round(self.h2o_kg, 1),
            "h2o_recovery_pct": h2o_rec*100,
            "co2_cap_kg_day":   round(self.co2_scrubbing_capacity_kg_day(), 2),
            "pressure_Pa":      101325.0,
            "cabin_temp_C":     21.0,
        }

    def propulsion_status(self) -> Dict[str, Any]:
        isp  = 9000.0; g0 = 9.80665
        m_ship= 500_000.0
        dv_remaining = isp*g0*math.log((m_ship + self.fuel_kg)/max(m_ship, 1))
        return {
            "fuel_kg":        round(self.fuel_kg, 0),
            "Isp_s":          isp,
            "dv_remaining_ms":round(dv_remaining, 0),
            "dv_remaining_kms":round(dv_remaining/1e3, 2),
            "main_engine_status": "NOMINAL",
            "rcs_status":     "NOMINAL",
        }

    def power_status(self) -> Dict[str, Any]:
        total_draw = self.total_power_kw()
        balance    = self.power_balance_kw()
        return {
            "reactor_kw":    self.reactor_power_kw,
            "total_draw_kw": round(total_draw, 1),
            "balance_kw":    round(balance, 1),
            "utilisation_pct": round(total_draw/max(self.reactor_power_kw,1)*100, 1),
            "critical": balance < -20.0,
        }

    def communications_status(self, dist_AU: float) -> Dict[str, Any]:
        """Signal lag and data rate at given distance."""
        lag_s    = dist_AU * AU / C_SI
        # Free-space path loss (2.4 GHz band, 5m dish)
        freq_hz  = 8.4e9   # X-band deep space
        lam_m    = C_SI/freq_hz
        dish_m   = 5.0; gain_dBi = 20*math.log10(math.pi*dish_m/lam_m)
        fspl_dB  = 20*math.log10(4*math.pi*dist_AU*AU/lam_m)
        rx_pwr_dBm = 40 + gain_dBi - fspl_dB  # 10W TX = 40 dBm
        data_rate_bps = max(0, 1e3 * 10**((rx_pwr_dBm + 120)/10) / 1e6)
        return {
            "distance_AU":    dist_AU,
            "signal_lag_s":   round(lag_s, 2),
            "signal_lag_min": round(lag_s/60, 3),
            "roundtrip_lag_min": round(lag_s/60*2, 3),
            "rx_power_dBm":   round(rx_pwr_dBm, 2),
            "data_rate_bps":  round(data_rate_bps, 0),
            "data_rate_kbps": round(data_rate_bps/1e3, 3),
            "dish_gain_dBi":  round(gain_dBi, 1),
        }

    def full_systems_report(self, n_active_crew: int = 4,
                             dist_AU: float = 10.0) -> Dict[str, Any]:
        return {
            "mission_day":       self.mission_day,
            "hull_integrity_pct":round(self.hull_integrity, 2),
            "artificial_g":      round(self.artificial_gravity(), 3),
            "rotation_rpm":      self.rotation_rpm,
            "modules_nominal":   sum(1 for m in self.modules
                                     if m.status == ModuleStatus.NOMINAL),
            "modules_degraded":  sum(1 for m in self.modules
                                     if m.status == ModuleStatus.DEGRADED),
            **self.life_support_status(n_active_crew),
            **self.power_status(),
            **self.propulsion_status(),
            **self.communications_status(dist_AU),
        }

    def module_dataframe(self) -> pd.DataFrame:
        rows = [{"Module #": m.module_id, "Type": m.type.value,
                 "Status": m.status.value, "Integrity%": m.integrity,
                 "Power (kW)": m.power_draw, "Temp (°C)": m.temperature,
                 "Health": round(m.health_score(), 1)}
                for m in self.modules]
        return pd.DataFrame(rows)


# ══════════════════════════════════════════════════════════════════════════════
# §6  CRYOSLEEP MANAGEMENT
# ══════════════════════════════════════════════════════════════════════════════
@dataclass
class CryosleepPod:
    """Individual cryosleep pod with full lifecycle management."""
    pod_id:         int
    occupant_name:  str = ""
    status:         CryoStatus = CryoStatus.EMPTY
    core_temp_C:    float = 37.0
    target_temp_C:  float = CRYO_TARGET_TEMP_C
    time_in_cryo_h: float = 0.0
    drug_dose_mg:   float = 0.0
    uid:            str   = field(default_factory=lambda: uuid.uuid4().hex[:6].upper())

    def induce_cryo(self, occupant: str) -> str:
        """Initiate cryosleep protocol."""
        self.occupant_name = occupant
        self.status        = CryoStatus.OCCUPIED
        self.core_temp_C   = 37.0
        self.drug_dose_mg  = 50.0   # initial sedative dose [mg]
        return f"CRYO POD {self.pod_id}: Induction started for {occupant}"

    def update_cooling(self, dt_h: float) -> Dict[str, float]:
        """Simulate cooling protocol: ~1°C/h until target."""
        if self.status != CryoStatus.OCCUPIED:
            return {}
        cooling_rate = min(1.0, abs(self.core_temp_C - self.target_temp_C))
        self.core_temp_C  -= cooling_rate * dt_h
        self.core_temp_C   = max(self.target_temp_C, self.core_temp_C)
        self.time_in_cryo_h += dt_h
        metabolism_suppression = max(0.0, 1.0 - (37-self.core_temp_C)/21 * 0.9)
        return {
            "core_temp_C":            round(self.core_temp_C, 2),
            "time_in_cryo_h":         round(self.time_in_cryo_h, 1),
            "metabolism_pct":         round(metabolism_suppression*100, 1),
            "at_target":              abs(self.core_temp_C - self.target_temp_C) < 0.5,
        }

    def revival_protocol(self) -> List[Dict]:
        """
        Revival protocol sequence: 8-step rewarming process.
        Returns timeline of revival steps.
        """
        steps = [
            {"step": 1, "action": "Terminate cryo-sedative infusion",
             "duration_min": 5, "temp_C": self.target_temp_C},
            {"step": 2, "action": "Begin active rewarming (1°C/30 min)",
             "duration_min": 210, "temp_C": self.target_temp_C + 7},
            {"step": 3, "action": "Cardiovascular stimulant administration",
             "duration_min": 10, "temp_C": 23.0},
            {"step": 4, "action": "Respiratory reactivation (ventilator)",
             "duration_min": 30, "temp_C": 27.0},
            {"step": 5, "action": "Neurological monitoring — EEG activation",
             "duration_min": 60, "temp_C": 30.0},
            {"step": 6, "action": "Core temperature: 34°C — consciousness expected",
             "duration_min": 45, "temp_C": 34.0},
            {"step": 7, "action": "Oral hydration + nutrient IV",
             "duration_min": 20, "temp_C": 36.5},
            {"step": 8, "action": "Motor function test — crew cleared for duty",
             "duration_min": 15, "temp_C": 37.0},
        ]
        return steps

    def cellular_aging_rate(self) -> float:
        """
        Cryo reduces metabolic rate → reduces aging.
        Aging rate ≈ 10% of normal at CRYO_TARGET_TEMP_C.
        """
        T_norm = 37.0
        T_cryo = self.target_temp_C
        Q10    = 2.3   # metabolic Q10 for mammals
        rate   = Q10**((T_cryo - T_norm)/10)
        return rate   # fraction of normal aging rate (~0.10)


class CryosleepBay:
    """Manage all cryosleep pods aboard Endurance."""

    def __init__(self, n_pods: int = 6):
        self.pods = [CryosleepPod(i) for i in range(n_pods)]

    def status_all(self) -> pd.DataFrame:
        rows = []
        for pod in self.pods:
            aging = pod.cellular_aging_rate() if pod.status == CryoStatus.OCCUPIED else 1.0
            rows.append({
                "Pod #":     pod.pod_id,
                "Status":    pod.status.value,
                "Occupant":  pod.occupant_name or "—",
                "Temp (°C)": round(pod.core_temp_C, 2),
                "Time (h)":  round(pod.time_in_cryo_h, 1),
                "Aging rate":round(aging, 3),
            })
        return pd.DataFrame(rows)

    def canonical_crew_status(self, mission_phase: str = "saturn_transit") -> pd.DataFrame:
        """Canon Interstellar crew cryosleep status by mission phase."""
        phases = {
            "saturn_transit": [
                ("Cooper", CryoStatus.OCCUPIED, CRYO_TARGET_TEMP_C, 2160),
                ("Brand",  CryoStatus.OCCUPIED, CRYO_TARGET_TEMP_C, 2160),
                ("Romilly",CryoStatus.OCCUPIED, CRYO_TARGET_TEMP_C, 2160),
                ("Doyle",  CryoStatus.OCCUPIED, CRYO_TARGET_TEMP_C, 2160),
            ],
            "miller_approach": [
                ("Cooper", CryoStatus.STANDBY,   37.0, 0),
                ("Brand",  CryoStatus.STANDBY,   37.0, 0),
                ("Romilly",CryoStatus.OCCUPIED,  CRYO_TARGET_TEMP_C, 500),
                ("Doyle",  CryoStatus.STANDBY,   37.0, 0),
            ],
        }
        data = phases.get(mission_phase, phases["saturn_transit"])
        rows = []
        for name, status, temp, time_h in data:
            aging = CryosleepPod(0, name, status).cellular_aging_rate()
            rows.append({"Crew": name, "Cryo Status": status.value,
                         "Core Temp °C": temp, "Time in Cryo (h)": time_h,
                         "Aging Rate": round(aging if status==CryoStatus.OCCUPIED else 1.0, 3)})
        return pd.DataFrame(rows)


# ══════════════════════════════════════════════════════════════════════════════
# §7  CANONICAL CREW PROFILES
# ══════════════════════════════════════════════════════════════════════════════
def build_crew_roster(mission_days: float = 0.0) -> List[CrewMember]:
    """Build canonical ENDURANCE crew members with film-accurate profiles."""
    rng = random.Random(777)
    crew = [
        CrewMember("Cooper",  35.0, 82.0, 1.82, CrewStatus.ACTIVE,  mission_days),
        CrewMember("Brand",   32.0, 63.0, 1.68, CrewStatus.ACTIVE,  mission_days),
        CrewMember("Romilly", 40.0, 78.0, 1.75, CrewStatus.ACTIVE,  mission_days),
        CrewMember("Doyle",   38.0, 74.0, 1.79, CrewStatus.ACTIVE,  mission_days),
    ]
    # Set realistic stress based on mission day
    for c in crew:
        c.stress_index = min(80, 10 + mission_days*0.05 + rng.uniform(0, 15))
        c.update_vitals(activity_level=rng.uniform(0.1, 0.5))
    return crew


# ══════════════════════════════════════════════════════════════════════════════
# §8  SESSION STATE
# ══════════════════════════════════════════════════════════════════════════════
def init_crew_session():
    D: Dict[str, Any] = {
        "crew_tars":          RobotUnit("TARS",
                                        TARSPersonality(TARS_DEFAULT_HUMOR,
                                                        TARS_DEFAULT_HONESTY,
                                                        TARS_DEFAULT_COURAGE,
                                                        TARS_DEFAULT_OPS),
                                        mode=RobotMode.OPERATIONAL,
                                        hull_pct=100.0),
        "crew_case":          RobotUnit("CASE",
                                        TARSPersonality(60, 95, 80, 100),
                                        mode=RobotMode.COMPANION),
        "crew_roster":        None,
        "crew_ship":          EnduranceShip(0.0),
        "crew_cryo":          CryosleepBay(6),
        "crew_mission_day":   0.0,
        "crew_dist_AU":       10.0,
        "crew_n_active":      4,
        "crew_tars_humor":    TARS_DEFAULT_HUMOR,
        "crew_tars_honesty":  TARS_DEFAULT_HONESTY,
        "crew_tars_courage":  TARS_DEFAULT_COURAGE,
        "crew_tars_ops":      TARS_DEFAULT_OPS,
        "crew_dialogue":      None,
        "crew_phase":         "saturn_transit",
    }
    for k, v in D.items():
        if k not in st.session_state:
            st.session_state[k] = v

_MPL_CREW = {
    "figure.facecolor": "#050a08","axes.facecolor": "#070d0c",
    "axes.edgecolor": "#102018","axes.labelcolor": "#E8C46A",
    "axes.grid": True,"grid.color": "#0a1810","grid.linestyle": ":",
    "grid.alpha": 0.5,"xtick.color": "#306040","ytick.color": "#306040",
    "xtick.labelsize": 6,"ytick.labelsize": 6,"axes.labelsize": 7,
    "axes.titlesize": 8,"axes.titlecolor": "#E8C46A","text.color": "#E8C46A",
    "font.family": "monospace","legend.facecolor": "#070d0c",
    "legend.edgecolor": "#102018","legend.fontsize": 6,
    "figure.dpi": 110,"savefig.facecolor": "#050a08",
    "axes.spines.top": False,"axes.spines.right": False,
}
def _mpl_c(): plt.rcParams.update(_MPL_CREW)


# ══════════════════════════════════════════════════════════════════════════════
# §9  PLOTTING
# ══════════════════════════════════════════════════════════════════════════════
def _plot_crew_health(roster: List[CrewMember]) -> plt.Figure:
    _mpl_c()
    fig, axes = plt.subplots(2, 3, figsize=(15, 8))
    fig.patch.set_facecolor("#050a08")
    names  = [c.name for c in roster]
    colors = ["#E8C46A","#4FC3F7","#81C784","#CE93D8"]
    x      = np.arange(len(names))
    def bar(ax, vals, ylabel, title, color_list=None):
        clrs = color_list or colors[:len(vals)]
        b = ax.bar(names, vals, color=clrs, alpha=0.85)
        ax.bar_label(b, fmt="%.1f", padding=2, fontsize=7, color="#fff")
        ax.set_ylabel(ylabel, fontsize=6); ax.set_title(title, fontsize=7)
        ax.set_facecolor("#070d0c"); ax.tick_params(axis="x", labelsize=7)
    reports = [c.full_report() for c in roster]
    bar(axes[0,0], [r["eva_readiness_pct"] for r in reports],
        "Score [%]", "EVA READINESS")
    bar(axes[0,1], [r["bone_density_pct"] for r in reports],
        "% of baseline", "BONE DENSITY")
    bar(axes[0,2], [r["muscle_mass_pct"] for r in reports],
        "% of baseline", "MUSCLE MASS")
    bar(axes[1,0], [r["radiation_mSv"] for r in reports],
        "mSv accumulated", "RADIATION DOSE")
    bar(axes[1,1], [r["cognitive_pct"] for r in reports],
        "Cognitive score [%]", "COGNITIVE PERFORMANCE")
    bar(axes[1,2], [r["stress_index"] for r in reports],
        "Stress index [0-100]", "PSYCHOLOGICAL STRESS")
    plt.tight_layout(); return fig


def _plot_vitals(roster: List[CrewMember]) -> plt.Figure:
    _mpl_c()
    fig, axes = plt.subplots(2, 3, figsize=(15, 8))
    fig.patch.set_facecolor("#050a08")
    names  = [c.name for c in roster]
    reports= [c.full_report() for c in roster]
    colors = ["#E8C46A","#4FC3F7","#81C784","#CE93D8"]
    def bar(ax, vals, ylabel, title, low=None, high=None):
        b = ax.bar(names, vals, color=colors[:len(vals)], alpha=0.85)
        ax.bar_label(b, fmt="%.1f", padding=2, fontsize=7, color="#fff")
        if low is not None: ax.axhline(low, color="#EF5350", lw=0.7, ls="--")
        if high is not None: ax.axhline(high, color="#EF5350", lw=0.7, ls="--")
        ax.set_ylabel(ylabel, fontsize=6); ax.set_title(title, fontsize=7)
        ax.set_facecolor("#070d0c")
    bar(axes[0,0], [r["heart_rate_bpm"] for r in reports], "BPM",
        "HEART RATE", 60, 100)
    bar(axes[0,1], [r["systolic_bp"] for r in reports], "mmHg",
        "SYSTOLIC BP", 90, 140)
    bar(axes[0,2], [r["spo2_pct"] for r in reports], "%",
        "O₂ SATURATION", 95, None)
    bar(axes[1,0], [r["resp_rate_rpm"] for r in reports], "breaths/min",
        "RESPIRATORY RATE", 12, 20)
    bar(axes[1,1], [r["core_temp_C"] for r in reports], "°C",
        "CORE TEMPERATURE", 36.5, 37.5)
    bar(axes[1,2], [r["kcal_day"] for r in reports], "kcal/day",
        "CALORIC REQUIREMENT")
    plt.tight_layout(); return fig


def _plot_ship_systems(ship: EnduranceShip, n_active: int, dist_AU: float) -> plt.Figure:
    _mpl_c()
    fig, axes = plt.subplots(2, 3, figsize=(15, 8))
    fig.patch.set_facecolor("#050a08")
    report = ship.full_systems_report(n_active, dist_AU)
    # Module status ring
    ax_ring = axes[0, 0]
    statuses = [m.status.value for m in ship.modules]
    status_colors = {"NOMINAL":"#81C784","DEGRADED":"#FFB74D",
                     "CRITICAL":"#EF5350","OFFLINE":"#3a4a70","DESTROYED":"#CE93D8"}
    counts = {s: statuses.count(s) for s in set(statuses)}
    clrs   = [status_colors.get(s, "#fff") for s in counts.keys()]
    ax_ring.pie(list(counts.values()), labels=list(counts.keys()),
                colors=clrs, startangle=90,
                textprops={"fontsize":6,"color":"#E8C46A"},
                autopct="%1.0f%%")
    ax_ring.set_title("MODULE STATUS DISTRIBUTION")
    # Power balance
    ax_pw = axes[0, 1]
    pw    = ship.power_status()
    cats  = ["Reactor", "Systems Draw", "Balance"]
    vals  = [pw["reactor_kw"], pw["total_draw_kw"], abs(pw["balance_kw"])]
    bar_c = ["#81C784","#EF5350","#4FC3F7"]
    b = ax_pw.bar(cats, vals, color=bar_c, alpha=0.85)
    ax_pw.bar_label(b, fmt="%.0f kW", padding=2, fontsize=7, color="#fff")
    ax_pw.set_title(f"POWER SYSTEM ({pw['utilisation_pct']:.0f}% utilised)")
    ax_pw.set_facecolor("#070d0c")
    # Life support
    ax_ls = axes[0, 2]
    ls    = ship.life_support_status(n_active)
    ls_cats= ["O₂ (days)", "H₂O (kg/10)", "CO₂ cap\n(kg/day×10)"]
    ls_vals= [ls["o2_days_remaining"], ls["h2o_kg"]/10, ls["co2_cap_kg_day"]*10]
    b = ax_ls.bar(ls_cats, ls_vals, color=["#4FC3F7","#81C784","#CE93D8"], alpha=0.85)
    ax_ls.bar_label(b, fmt="%.1f", padding=2, fontsize=7, color="#fff")
    ax_ls.set_title("LIFE SUPPORT RESERVES")
    ax_ls.set_facecolor("#070d0c")
    # Hull integrity over time
    ax_hi = axes[1, 0]
    days  = np.linspace(0, 1000, 300)
    hull  = 100.0 - 0.002 * days * np.random.poisson(0.5, 300)
    hull  = np.clip(np.cumsum(np.gradient(hull)), 70, 100)
    ax_hi.plot(days, hull, color="#E8C46A", lw=1.2)
    ax_hi.axhline(report["hull_integrity_pct"], color="#EF5350",
                   lw=0.8, ls="--", label=f"Current: {report['hull_integrity_pct']:.1f}%")
    ax_hi.set_xlabel("Mission days"); ax_hi.set_ylabel("Hull integrity [%]")
    ax_hi.set_title("HULL INTEGRITY PROJECTION"); ax_hi.legend(fontsize=6)
    # Comms
    ax_co = axes[1, 1]
    d_arr = np.logspace(0, 3, 200)
    lag_arr = d_arr*AU/C_SI/60
    ax_co.loglog(d_arr, lag_arr, color="#CE93D8", lw=1.2)
    ax_co.axvline(dist_AU, color="#E8C46A", lw=0.8, ls="--",
                   label=f"Current: {dist_AU:.1f}AU\nLag: {report['signal_lag_min']:.1f}min")
    ax_co.set_xlabel("Distance [AU]"); ax_co.set_ylabel("Signal lag [min]")
    ax_co.set_title("COMMUNICATION LAG vs DISTANCE"); ax_co.legend(fontsize=6)
    # Rotation / gravity
    ax_gr = axes[1, 2]
    rpm_arr = np.linspace(0, 5, 200)
    g_arr   = (rpm_arr/60*2*math.pi)**2 * ENDURANCE_RADIUS_M / 9.81
    ax_gr.plot(rpm_arr, g_arr, color="#4FC3F7", lw=1.2)
    ax_gr.axvline(ship.rotation_rpm, color="#E8C46A", lw=0.8, ls="--",
                   label=f"Endurance: {ship.rotation_rpm} RPM\n→ {ship.artificial_gravity():.3f}g")
    ax_gr.axhline(1.0, color="#81C784", lw=0.7, ls=":", label="Earth gravity")
    ax_gr.set_xlabel("Rotation rate [RPM]"); ax_gr.set_ylabel("Artificial gravity [g]")
    ax_gr.set_title("ARTIFICIAL GRAVITY vs ROTATION"); ax_gr.legend(fontsize=6)
    plt.tight_layout(); return fig


def _plot_tars_settings(tars: RobotUnit, case: RobotUnit) -> plt.Figure:
    _mpl_c()
    fig, axes = plt.subplots(1, 3, figsize=(14, 5))
    fig.patch.set_facecolor("#050a08")
    robots = [tars, case]
    for robot, ax in zip(robots, axes[:2]):
        caps = robot.personality.capability_matrix()
        clrs = ["#81C784" if s=="OPTIMAL" else "#FFB74D" if s=="GOOD"
                else "#FF8800" if s=="DEGRADED" else "#EF5350"
                for s in caps["Status"]]
        b = ax.barh(caps["Capability"], caps["Score"], color=clrs, alpha=0.85)
        ax.bar_label(b, fmt="%.0f", padding=3, fontsize=6, color="#fff")
        ax.set_xlim(0, 110)
        p = robot.personality
        ax.set_title(f"{robot.name} CAPABILITIES\n"
                     f"Humor:{p.humor}%  Honesty:{p.honesty}%  "
                     f"Courage:{p.courage}%  Ops:{p.operational}%")
        ax.set_facecolor("#070d0c")
    # Radar comparison
    ax3 = axes[2]
    params   = ["Humor","Honesty","Courage","Ops","Hull","Power","Op Score"]
    tars_v   = [tars.personality.humor, tars.personality.honesty,
                tars.personality.courage, tars.personality.operational,
                tars.hull_pct, tars.power_pct, tars.operational_score()]
    case_v   = [case.personality.humor, case.personality.honesty,
                case.personality.courage, case.personality.operational,
                case.hull_pct, case.power_pct, case.operational_score()]
    x = np.arange(len(params))
    w = 0.38
    ax3.bar(x-w/2, tars_v, w, label="TARS", color="#E8C46A", alpha=0.85)
    ax3.bar(x+w/2, case_v, w, label="CASE", color="#4FC3F7", alpha=0.85)
    ax3.set_xticks(x); ax3.set_xticklabels(params, rotation=30, ha="right", fontsize=6)
    ax3.set_ylabel("Score [%]"); ax3.set_title("TARS vs CASE COMPARISON")
    ax3.legend(fontsize=6); ax3.set_ylim(0, 110)
    ax3.set_facecolor("#070d0c")
    plt.tight_layout(); return fig


# ══════════════════════════════════════════════════════════════════════════════
# §10  MAIN PAGE
# ══════════════════════════════════════════════════════════════════════════════
def crew_telemetry_page():
    init_crew_session()
    _mpl_c()
    S = st.session_state

    st.markdown("""
    <div style="border-left:3px solid #81C784;padding:.55rem 1.2rem;
                margin-bottom:1.2rem;background:rgba(129,199,132,0.03);
                font-family:monospace;">
    <div style="color:#81C784;font-size:.95rem;letter-spacing:.12em;
                font-weight:600;">◈ CREW TELEMETRY &amp; SHIP SYSTEMS MONITOR</div>
    <div style="color:#5a6a90;font-size:.62rem;margin-top:.2rem;">
    TARS/CASE AI · Crew Health · Vital Signs · Ship Systems · Life Support ·
    Cryosleep · Communications · Module Status · Artificial Gravity
    </div></div>""", unsafe_allow_html=True)

    (tab_tars, tab_health, tab_vitals,
     tab_ship, tab_cryo, tab_comms) = st.tabs([
        "🤖 TARS & CASE AI",
        "🩺 CREW HEALTH",
        "💓 VITAL SIGNS",
        "🚀 SHIP SYSTEMS",
        "❄ CRYOSLEEP",
        "📡 COMMUNICATIONS",
    ])

    with tab_tars:
        c1, c2, c3 = st.columns([1, 1, 2])
        with c1:
            st.markdown('<div style="font-family:monospace;font-size:.62rem;color:#81C784;">[ TARS SETTINGS ]</div>',
                        unsafe_allow_html=True)
            h = st.slider("Humor setting",      0, 100, int(S["crew_tars_humor"]),   1)
            n = st.slider("Honesty setting",     0, 100, int(S["crew_tars_honesty"]), 1)
            g = st.slider("Courage setting",     0, 100, int(S["crew_tars_courage"]), 1)
            o = st.slider("Operational setting", 0, 100, int(S["crew_tars_ops"]),     1)
            S["crew_tars_humor"]=h; S["crew_tars_honesty"]=n
            S["crew_tars_courage"]=g; S["crew_tars_ops"]=o
            tars_p = TARSPersonality(h, n, g, o)
            S["crew_tars"].personality = tars_p
            if st.button("🤖 GENERATE TARS DIALOGUE", use_container_width=True, type="primary"):
                S["crew_dialogue"] = tars_p.generate_batch_dialogue(8)
        with c2:
            st.markdown('<div style="font-family:monospace;font-size:.62rem;color:#4FC3F7;">[ CASE SETTINGS ]</div>',
                        unsafe_allow_html=True)
            ch = st.slider("CASE Humor",   0, 100, 60, 1)
            cn = st.slider("CASE Honesty", 0, 100, 95, 1)
            cg = st.slider("CASE Courage", 0, 100, 80, 1)
            co = st.slider("CASE Ops",     0, 100, 100, 1)
            S["crew_case"].personality = TARSPersonality(ch, cn, cg, co)
            su_t = S["crew_tars"].status_summary()
            su_c = S["crew_case"].status_summary()
            st.markdown(f"""
            <div style="font-family:monospace;font-size:.56rem;color:#c0c8e0;
                        background:rgba(7,13,12,.92);padding:.55rem;
                        border:1px solid rgba(129,199,132,.12);border-radius:3px;
                        line-height:1.85;">
            <b style="color:#81C784;">TARS</b> — Hull:{su_t['hull%']}%  Op:{su_t['op_score']}  {su_t['readiness']}<br>
            Mode: {su_t['mode']}<br><br>
            <b style="color:#4FC3F7;">CASE</b> — Hull:{su_c['hull%']}%  Op:{su_c['op_score']}  {su_c['readiness']}<br>
            Mode: {su_c['mode']}
            </div>""", unsafe_allow_html=True)
        with c3:
            fig = _plot_tars_settings(S["crew_tars"], S["crew_case"])
            st.pyplot(fig, use_container_width=True); plt.close(fig)
        if S.get("crew_dialogue"):
            st.markdown('<div style="font-family:monospace;font-size:.62rem;color:#81C784;">TARS DIALOGUE LOG</div>',
                        unsafe_allow_html=True)
            st.dataframe(pd.DataFrame(S["crew_dialogue"]),
                         use_container_width=True, hide_index=True)

    with tab_health:
        c1, c2 = st.columns([1, 3])
        with c1:
            days = st.slider("Mission days elapsed", 0.0, 1000.0,
                              float(S["crew_mission_day"]), 1.0)
            S["crew_mission_day"] = days
            if st.button("🩺 UPDATE CREW HEALTH", use_container_width=True, type="primary"):
                S["crew_roster"] = build_crew_roster(days)
        with c2:
            roster = S.get("crew_roster") or build_crew_roster(S["crew_mission_day"])
            S["crew_roster"] = roster
            fig = _plot_crew_health(roster)
            st.pyplot(fig, use_container_width=True); plt.close(fig)
        with st.expander("◈ Full Crew Health Table"):
            df_h = pd.DataFrame([c.full_report() for c in roster])
            st.dataframe(df_h.round(2), use_container_width=True, hide_index=True)

    with tab_vitals:
        roster = S.get("crew_roster") or build_crew_roster(S["crew_mission_day"])
        fig = _plot_vitals(roster)
        st.pyplot(fig, use_container_width=True); plt.close(fig)

    with tab_ship:
        c1, c2 = st.columns([1, 3])
        with c1:
            dist  = st.slider("Distance from Earth [AU]", 0.1, 5000.0,
                               float(S["crew_dist_AU"]), 0.5)
            nact  = st.slider("Active crew count", 0, 4, int(S["crew_n_active"]), 1)
            S["crew_dist_AU"] = dist; S["crew_n_active"] = nact
            ship  = S["crew_ship"]
            rep   = ship.full_systems_report(nact, dist)
            st.markdown(f"""
            <div style="font-family:monospace;font-size:.57rem;color:#c0c8e0;
                        background:rgba(7,13,12,.92);padding:.65rem;
                        border:1px solid rgba(129,199,132,.15);border-radius:3px;
                        line-height:2.0;">
            Hull integrity: <b style="color:{'#81C784' if rep['hull_integrity_pct']>90 else '#FFB74D'}">{rep['hull_integrity_pct']:.1f}%</b><br>
            Artificial g: <b style="color:#E8C46A;">{rep['artificial_g']:.3f}g</b><br>
            Rotation: <b>{rep['rotation_rpm']} RPM</b><br>
            O₂ days left: <b style="color:#4FC3F7;">{rep['o2_days_remaining']:.0f} days</b><br>
            Power balance: <b style="color:{'#81C784' if rep['balance_kw']>0 else '#EF5350'}">{rep['balance_kw']:.0f} kW</b><br>
            Δv remaining: <b>{rep['dv_remaining_kms']:.1f} km/s</b><br>
            Signal lag: <b style="color:#CE93D8;">{rep['signal_lag_min']:.1f} min</b><br>
            Data rate: <b>{rep['data_rate_kbps']:.2f} kbps</b>
            </div>""", unsafe_allow_html=True)
        with c2:
            fig = _plot_ship_systems(ship, nact, dist)
            st.pyplot(fig, use_container_width=True); plt.close(fig)
        with st.expander("◈ Module Status Table"):
            st.dataframe(ship.module_dataframe(), use_container_width=True, hide_index=True)

    with tab_cryo:
        cryo  = S["crew_cryo"]
        phase = st.selectbox("Mission phase", ["saturn_transit","miller_approach"])
        S["crew_phase"] = phase
        canon = cryo.canonical_crew_status(phase)
        st.markdown('<div style="font-family:monospace;font-size:.62rem;color:#81C784;">CANONICAL CRYOSLEEP STATUS</div>',
                    unsafe_allow_html=True)
        st.dataframe(canon, use_container_width=True, hide_index=True)
        st.markdown("---")
        st.markdown("**Revival Protocol Timeline:**")
        pod  = CryosleepPod(0, "Cooper", CryoStatus.OCCUPIED, CRYO_TARGET_TEMP_C)
        revl = pod.revival_protocol()
        st.dataframe(pd.DataFrame(revl), use_container_width=True, hide_index=True)

    with tab_comms:
        ship = S["crew_ship"]
        dist = S["crew_dist_AU"]
        _mpl_c()
        fig_c, axes_c = plt.subplots(1, 2, figsize=(12, 5))
        fig_c.patch.set_facecolor("#050a08")
        d_arr    = np.logspace(0, 4, 300)
        lag_arr  = d_arr*AU/C_SI/60
        rate_arr = []
        for d in d_arr:
            cs = ship.communications_status(d)
            rate_arr.append(cs["data_rate_kbps"])
        axes_c[0].loglog(d_arr, lag_arr, color="#CE93D8", lw=1.3, label="Signal lag [min]")
        axes_c[0].axvline(dist, color="#E8C46A", lw=0.8, ls="--",
                           label=f"Current {dist:.0f}AU")
        axes_c[0].set_xlabel("Distance [AU]"); axes_c[0].set_ylabel("Lag [min]")
        axes_c[0].set_title("SIGNAL LAG vs DISTANCE"); axes_c[0].legend(fontsize=6)
        axes_c[1].loglog(d_arr, np.array(rate_arr)+1e-10, color="#4FC3F7",
                          lw=1.3, label="Data rate [kbps]")
        axes_c[1].axvline(dist, color="#E8C46A", lw=0.8, ls="--",
                           label=f"Current {dist:.0f}AU")
        axes_c[1].set_xlabel("Distance [AU]"); axes_c[1].set_ylabel("Rate [kbps]")
        axes_c[1].set_title("DATA RATE vs DISTANCE"); axes_c[1].legend(fontsize=6)
        plt.tight_layout()
        st.pyplot(fig_c, use_container_width=True); plt.close(fig_c)
        cs = ship.communications_status(dist)
        st.markdown(f"""
        <div style="font-family:monospace;font-size:.62rem;color:#c0c8e0;
                    background:rgba(7,13,12,.92);padding:.5rem;
                    border:1px solid rgba(129,199,132,.12);border-radius:3px;">
        Distance: <b>{dist:.1f} AU</b>  ·
        Lag: <b style="color:#CE93D8;">{cs['signal_lag_min']:.2f} min  (RT: {cs['roundtrip_lag_min']:.2f} min)</b>  ·
        Data rate: <b style="color:#4FC3F7;">{cs['data_rate_kbps']:.3f} kbps</b>  ·
        RX power: <b>{cs['rx_power_dBm']:.1f} dBm</b>
        </div>""", unsafe_allow_html=True)




"""
mission_reporter.py — Mission Planning, Lazarus Archive & Plan A/B Engine
ENDURANCE Mission Control | Interstellar Science Platform v3.0.0
═══════════════════════════════════════════════════════════════════════════════
References:
  [1] Kip Thorne, "The Science of Interstellar" (W.W. Norton, 2014)
  [2] NASA Mission Design & Analysis (various)
  [3] Weir, A., "The Martian" — mission autonomy reference
  [4] Film canon: Interstellar (2014), dir. Christopher Nolan

Module implements:
  ┌─ LAZARUS MISSION ARCHIVE ───────────────────────────────────────────────┐
  │ 12 Lazarus probe missions: launch dates, scientists, planet data        │
  │ Signal analysis for each probe: quality, habitability vote              │
  │ Data reliability model: signal decay over 10+ year transit             │
  │ Mission correlation: which data is genuine vs falsified                 │
  └──────────────────────────────────────────────────────────────────────────┘
  ┌─ PLAN A ENGINE ─────────────────────────────────────────────────────────┐
  │ Gravity equation completion tracking (0–100%)                          │
  │ Data required from Gargantua singularity                               │
  │ Station construction model: population lift capacity                   │
  │ Brand's deception timeline: when/how Plan A was abandoned              │
  │ Post-TARS: Murphy's solution → stations launched                       │
  └──────────────────────────────────────────────────────────────────────────┘
  ┌─ PLAN B ENGINE ─────────────────────────────────────────────────────────┐
  │ Embryo bank: 5,000 frozen embryos, genetic diversity model             │
  │ Colony growth simulation: generation-by-generation population model    │
  │ Resource requirements: land area, water, food production               │
  │ Technology preservation: knowledge base compression estimate           │
  │ Planet suitability scoring for colony survival                         │
  └──────────────────────────────────────────────────────────────────────────┘
  ┌─ MISSION SCORER ────────────────────────────────────────────────────────┐
  │ Points system: scientific discovery, crew survival, plan completion    │
  │ Achievement unlocks: first contact data, Miller data, Mann betrayal   │
  │ Mission outcome classification: COMPLETE/PARTIAL/FAILED                │
  │ Historical comparison: how ENDURANCE ranks vs other space missions     │
  └──────────────────────────────────────────────────────────────────────────┘
  ┌─ DATA DRIVE SYSTEM ─────────────────────────────────────────────────────┐
  │ SHA-256 hashing of mission data packages                               │
  │ Drive submission log: timestamp, hash, size, status                    │
  │ Data integrity verification                                            │
  │ TARS crystal data package builder                                      │
  └──────────────────────────────────────────────────────────────────────────┘
"""
from __future__ import annotations

import hashlib
import json
import math
import time
import uuid
import warnings
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot   as plt
import matplotlib.gridspec as gridspec
import matplotlib.colors   as mcolors
from matplotlib.colors     import LinearSegmentedColormap
import matplotlib.patches  as mpatches

import streamlit as st

warnings.filterwarnings("ignore")

# ══════════════════════════════════════════════════════════════════════════════
# §1  CONSTANTS
# ══════════════════════════════════════════════════════════════════════════════
YEAR_S    = 3.155_760e7
C_SI      = 2.997_924_58e8
PLAN_B_EMBRYOS    = 5_000
PLAN_B_TARGET_POP = 1_000_000_000   # 1 billion colony target
EARTH_POPULATION  = 8_000_000_000
LAZARUS_COUNT     = 12

# ══════════════════════════════════════════════════════════════════════════════
# §2  ENUMERATIONS
# ══════════════════════════════════════════════════════════════════════════════
class LazarusStatus(Enum):
    CONFIRMED_VIABLE = "CONFIRMED VIABLE"
    VIABLE_CANDIDATE = "VIABLE CANDIDATE"
    MARGINAL         = "MARGINAL — uncertain"
    DATA_FALSIFIED   = "DATA FALSIFIED (Mann)"
    SIGNAL_LOST      = "SIGNAL LOST"
    DECEASED_AGENT   = "AGENT DECEASED"
    UNKNOWN          = "UNKNOWN"

class PlanStatus(Enum):
    NOT_STARTED = "Not started"
    IN_PROGRESS = "In progress"
    BLOCKED     = "Blocked — missing data"
    COMPLETE    = "COMPLETE"
    ABANDONED   = "ABANDONED"

class MissionOutcome(Enum):
    COMPLETE_A  = "MISSION COMPLETE — Plan A enacted"
    COMPLETE_B  = "MISSION COMPLETE — Plan B enacted"
    PARTIAL     = "PARTIAL SUCCESS"
    FAILED      = "MISSION FAILED"
    ONGOING     = "ONGOING"

class DriveStatus(Enum):
    PENDING   = "PENDING"
    SUBMITTED = "SUBMITTED"
    VERIFIED  = "VERIFIED"
    CORRUPTED = "CORRUPTED"
    RECEIVED  = "RECEIVED BY NASA"

# ══════════════════════════════════════════════════════════════════════════════
# §3  LAZARUS MISSION DATABASE
# ══════════════════════════════════════════════════════════════════════════════
@dataclass
class LazarusProbe:
    """One Lazarus mission probe record."""
    mission_id:    int
    scientist:     str
    planet_name:   str
    launch_year:   int
    signal_year:   int       # year signal received on Earth
    habitable_vote:bool
    signal_quality:float     # 0–1
    status:        LazarusStatus
    notes:         str = ""
    uid:           str = field(default_factory=lambda: uuid.uuid4().hex[:6].upper())

    def signal_age_yr(self, current_year: int = 2067) -> float:
        return current_year - self.signal_year

    def reliability_score(self) -> float:
        """
        Data reliability = signal quality × recency × integrity.
        Falsified data (Mann) gets near-zero despite claimed quality.
        """
        if self.status == LazarusStatus.DATA_FALSIFIED:
            return 0.05 * self.signal_quality
        recency = max(0.0, 1.0 - self.signal_age_yr()/50)
        return self.signal_quality * 0.7 + recency * 0.3


class LazarusArchive:
    """Complete Lazarus mission archive — all 12 probes."""

    PROBES: List[LazarusProbe] = [
        LazarusProbe(1,  "Dr. Wolf Edmunds",  "Edmunds' Planet", 2047, 2059, True,  0.88,
                     LazarusStatus.DECEASED_AGENT,
                     "Strongest positive signal. Edmunds confirmed habitable. Agent deceased on arrival."),
        LazarusProbe(2,  "Dr. Laura Miller",  "Miller's World",  2048, 2055, True,  0.72,
                     LazarusStatus.CONFIRMED_VIABLE,
                     "Ocean world confirmed. Massive tidal activity. Extreme GR time dilation."),
        LazarusProbe(3,  "Dr. Hugh Mann",     "Mann's Planet",   2049, 2058, True,  0.91,
                     LazarusStatus.DATA_FALSIFIED,
                     "DATA FALSIFIED. Mann fabricated habitability signal to ensure rescue."),
        LazarusProbe(4,  "Dr. Chen",          "Chen's World",    2046, 2052, False, 0.55,
                     LazarusStatus.SIGNAL_LOST,
                     "Signal degraded. Last transmission indicated hostile atmosphere."),
        LazarusProbe(5,  "Dr. Rutherford",    "Rutherford Station",2047, 2056, False,0.62,
                     LazarusStatus.MARGINAL,
                     "Marginal habitability. High CO₂. Signal weak but consistent."),
        LazarusProbe(6,  "Dr. Singh",         "Singh's World",   2048, 2054, False, 0.40,
                     LazarusStatus.SIGNAL_LOST,
                     "Signal lost after 6 years. Presumed environmental failure."),
        LazarusProbe(7,  "Dr. Park",          "Kepler-452b-Z",   2049, 2061, False, 0.33,
                     LazarusStatus.UNKNOWN,
                     "Late signal. Irregular transmission pattern. Status uncertain."),
        LazarusProbe(8,  "Dr. Kowalski",      "Kowalski Alpha",  2050, 2059, False, 0.28,
                     LazarusStatus.SIGNAL_LOST,
                     "Brief signal then silence. Likely catastrophic atmospheric event."),
        LazarusProbe(9,  "Dr. Osei",          "Osei's World",    2050, 2063, False, 0.51,
                     LazarusStatus.MARGINAL,
                     "Borderline signal. Thin atmosphere. Possible subsurface ocean."),
        LazarusProbe(10, "Dr. Torres",        "Torres Prime",    2051, 2060, False, 0.45,
                     LazarusStatus.SIGNAL_LOST,
                     "Initial positive, then signal collapse. Volcanic activity suspected."),
        LazarusProbe(11, "Dr. Reyes",         "Reyes Station",   2051, 2062, False, 0.38,
                     LazarusStatus.MARGINAL,
                     "Weak habitable signal. High radiation environment."),
        LazarusProbe(12, "Dr. Okafor",        "Okafor's World",  2052, 2065, False, 0.22,
                     LazarusStatus.UNKNOWN,
                     "Most recent signal. Inconclusive data. Possibly rich in water ice."),
    ]

    def to_dataframe(self) -> pd.DataFrame:
        rows = [{"ID": p.mission_id, "Scientist": p.scientist,
                 "Planet": p.planet_name, "Launched": p.launch_year,
                 "Signal received": p.signal_year,
                 "Habitable vote": "YES" if p.habitable_vote else "NO",
                 "Signal quality": round(p.signal_quality, 2),
                 "Reliability": round(p.reliability_score(), 3),
                 "Status": p.status.value, "Notes": p.notes[:50]+"..."}
                for p in self.PROBES]
        return pd.DataFrame(rows)

    def top_candidates(self, n: int = 3) -> List[LazarusProbe]:
        scored = [(p, p.reliability_score()) for p in self.PROBES if p.habitable_vote]
        scored.sort(key=lambda x: -x[1])
        return [p for p, _ in scored[:n]]

    def signal_quality_timeline(self) -> pd.DataFrame:
        rows = [{"Year": p.signal_year, "Mission": p.scientist,
                 "Planet": p.planet_name, "Quality": p.signal_quality,
                 "Habitable": p.habitable_vote, "Status": p.status.value}
                for p in self.PROBES]
        return pd.DataFrame(rows).sort_values("Year")


# ══════════════════════════════════════════════════════════════════════════════
# §4  PLAN A ENGINE
# ══════════════════════════════════════════════════════════════════════════════
class PlanAEngine:
    """
    Plan A: Solve the gravity equation and use it to levitate humanity
    off Earth into space stations. Requires singularity data from Gargantua.

    Prof. Brand worked on this for 40+ years (2023–2067).
    Brand secretly knew it was impossible without quantum gravity data
    from inside a black hole singularity — data that can only be retrieved
    by someone inside (TARS) and sent back (via tesseract/Cooper).
    """

    def __init__(self, years_worked: float = 44.0,
                 singularity_data_pct: float = 0.0):
        self.years_worked = years_worked
        self.singularity_data_pct = singularity_data_pct

    def equation_completion(self) -> float:
        """
        Equation completion fraction.
        Without singularity data: asymptotes at ~35% (the mathematical barrier).
        With complete data (100%): reaches 100%.
        """
        theoretical_max = 0.35 + 0.65 * self.singularity_data_pct/100
        progress_curve  = 1 - math.exp(-self.years_worked/20)
        return min(theoretical_max, progress_curve)

    def stations_needed(self, lift_capacity_kg: float = 1e12) -> int:
        """Number of stations needed to evacuate Earth's 8 billion people."""
        mass_per_person = 80.0 + 500.0   # body + survival kit [kg]
        total_mass      = EARTH_POPULATION * mass_per_person
        return max(1, math.ceil(total_mass / max(lift_capacity_kg, 1)))

    def station_parameters(self) -> Dict[str, Any]:
        """O'Neill cylinder-style space station parameters for Plan A."""
        pop_per_station = 10_000
        n_stations      = math.ceil(EARTH_POPULATION / pop_per_station)
        station_radius  = 4000.0    # [m] (O'Neill cylinder radius)
        station_length  = 32_000.0  # [m]
        return {
            "people_per_station":   pop_per_station,
            "n_stations_needed":    n_stations,
            "station_radius_m":     station_radius,
            "station_length_m":     station_length,
            "station_area_km2":     2*math.pi*station_radius*station_length/1e6,
            "mass_per_station_kg":  1e10,   # ~10 million tonnes
            "gravity_rotation_rpm": 60/(2*math.pi)*math.sqrt(9.81/station_radius),
        }

    def timeline(self) -> pd.DataFrame:
        """Plan A development timeline with key events."""
        events = [
            (2023, "Prof. Brand begins gravity equation research at NASA"),
            (2035, "First partial solutions — discovers singularity data requirement"),
            (2040, "NASA realises equation is unsolvable without BH interior data"),
            (2045, "Brand privately acknowledges impossibility — conceals from public"),
            (2047, "Lazarus missions launched — Plan B backup initiated"),
            (2063, "Endurance launched — Brand tells Cooper Plan A is primary"),
            (2067, "Murphy discovers Brand's secret — Plan A was never viable without TARS data"),
            (2067, "TARS returns from Gargantua singularity with quantum data"),
            (2068, "Murphy completes equation with singularity data — Plan A viable"),
            (2070, "First gravity stations launched — evacuation begins"),
        ]
        rows = [{"Year": y, "Event": e,
                 "Plan A viability": f"{min(100,max(0,(y-2023)*2.2)):.0f}%"}
                for y, e in events]
        return pd.DataFrame(rows)

    def brand_deception_analysis(self) -> Dict[str, Any]:
        return {
            "knew_impossible_from_yr": 2040,
            "years_of_deception":      27,
            "motive":                  "Protect Plan B from abandonment; preserve hope",
            "effect":                  "Endurance crew risked lives for impossible mission",
            "murphy_discovery_yr":     2067,
            "ethical_verdict":         "Consequentialist: secured species survival via Plan B",
            "plan_b_success_without":  True,
            "plan_a_success_with_TARS":True,
        }

    def summary(self) -> Dict[str, Any]:
        comp   = self.equation_completion()
        params = self.station_parameters()
        return {
            "years_worked":         self.years_worked,
            "singularity_data_pct": self.singularity_data_pct,
            "equation_completion":  round(comp*100, 2),
            "plan_viable":          comp >= 0.99,
            "theoretical_max_pct":  round((0.35 + 0.65*self.singularity_data_pct/100)*100, 2),
            "stations_needed":      params["n_stations_needed"],
            "area_per_station_km2": params["station_area_km2"],
            "status": (PlanStatus.COMPLETE.value if comp >= 0.99
                       else PlanStatus.BLOCKED.value if self.singularity_data_pct < 50
                       else PlanStatus.IN_PROGRESS.value),
        }


# ══════════════════════════════════════════════════════════════════════════════
# §5  PLAN B ENGINE
# ══════════════════════════════════════════════════════════════════════════════
class PlanBEngine:
    """
    Plan B: Seed a new world with 5,000 frozen embryos from Edmunds' Planet.
    Grow a self-sustaining colony through artificial reproduction,
    then natural reproduction once population exceeds ~150 individuals
    (minimum viable population for genetic diversity).
    """

    MVP = 150    # minimum viable population for long-term survival

    def __init__(self, n_embryos: int = PLAN_B_EMBRYOS,
                 target_planet_esi: float = 0.78):
        self.n_embryos = n_embryos
        self.esi       = target_planet_esi

    def genetic_diversity_index(self) -> float:
        """
        Genetic diversity of embryo bank.
        5000 embryos from diverse donors → high initial diversity.
        Inbreeding depression risk at small population bottleneck.
        Index 0–1 where 1 = maximal diversity.
        """
        # Each embryo from unique donor pair → n_unique_alleles ∝ √n_embryos
        n_unique_alleles = math.sqrt(self.n_embryos) * 2
        max_alleles      = 20_000.0   # human genome ~20k gene loci
        return min(1.0, n_unique_alleles / max_alleles)

    def population_model(self, n_years: int = 500) -> pd.DataFrame:
        """
        Colony population growth model:
        Phase 1 (0–50 yr): artificial wombs + nurse robots → 5000 initial
        Phase 2 (50–150 yr): natural reproduction kicks in, r~0.03/yr
        Phase 3 (150+ yr): logistic growth toward planet carrying capacity.
        Carrying capacity: ~planet_esi × 10 billion.
        """
        K = self.esi * 1e10    # carrying capacity
        r = 0.030              # growth rate
        rows = []
        pop  = float(self.n_embryos)   # start with all embryos
        for yr in range(0, n_years+1, 5):
            # Logistic growth dP/dt = rP(1−P/K)
            growth = r * pop * (1 - pop/K)
            for _ in range(5):
                pop = max(self.n_embryos,
                          pop + r*pop*(1-pop/K)*1.0)
            rows.append({
                "Year":       yr,
                "Population": round(pop, 0),
                "Phase":      ("Artificial reproduction" if pop < 5000
                               else "Early natural repro" if pop < 50_000
                               else "Rapid expansion" if pop < 1e6
                               else "Logistic plateau"),
                "Gen_number": yr // 30,
                "MVP_achieved": pop >= self.MVP,
            })
        return pd.DataFrame(rows)

    def resource_requirements(self, population: float = 5000) -> Dict[str, Any]:
        """Resource needs for a given colony population."""
        food_kcal_day    = population * 2200
        water_L_day      = population * 2.5
        o2_kg_day        = population * 0.84
        land_m2          = population * 200   # 200 m² per person (food + living)
        energy_kWh_day   = population * 30
        return {
            "population":       population,
            "food_kcal_day":    food_kcal_day,
            "food_tonnes_yr":   food_kcal_day*365/4e6,
            "water_L_day":      water_L_day,
            "water_tonnes_yr":  water_L_day*365/1000,
            "o2_kg_day":        o2_kg_day,
            "land_km2":         land_m2/1e6,
            "energy_kWh_day":   energy_kWh_day,
            "energy_GWh_yr":    energy_kWh_day*365/1e6,
        }

    def knowledge_preservation_estimate(self) -> Dict[str, Any]:
        """
        Estimate data volume needed to preserve human knowledge base.
        Wikipedia: ~22 GB; all scientific papers: ~100 TB; all books: ~640 TB.
        TARS crystal + ship computers: ~petabyte capacity.
        """
        return {
            "wikipedia_GB":        22,
            "scientific_papers_TB":100,
            "all_books_TB":        640,
            "art_music_TB":        2000,
            "video_archive_PB":    10,
            "TARS_crystal_GB":     PLAN_B_EMBRYOS * 0.02,   # DNA + notes per embryo
            "ship_storage_TB":     500,
            "coverage_pct":        min(100, 500/(640+100)*100),
            "generations_to_rebuild_tech": 3,
        }

    def summary(self) -> Dict[str, Any]:
        pop_100yr = None
        pop_df    = self.population_model(200)
        p100      = pop_df[pop_df["Year"]==100]["Population"].values
        pop_100yr = float(p100[0]) if len(p100) else 0.0
        return {
            "n_embryos":         self.n_embryos,
            "target_esi":        self.esi,
            "genetic_diversity": round(self.genetic_diversity_index(), 4),
            "mvp_met_yr":        int(pop_df[pop_df["MVP_achieved"]]["Year"].min())
                                 if pop_df["MVP_achieved"].any() else -1,
            "population_100yr":  round(pop_100yr, 0),
            "carrying_capacity": round(self.esi * 1e10, 0),
            "land_needed_km2":   round(self.resource_requirements(self.n_embryos)["land_km2"], 2),
            "plan_viable":       self.esi >= 0.6,
            "status":            PlanStatus.COMPLETE.value if self.esi >= 0.7
                                 else PlanStatus.IN_PROGRESS.value,
        }


# ══════════════════════════════════════════════════════════════════════════════
# §6  MISSION SCORER
# ══════════════════════════════════════════════════════════════════════════════
@dataclass
class Achievement:
    name:        str
    description: str
    points:      int
    unlocked:    bool = False
    uid:         str  = field(default_factory=lambda: uuid.uuid4().hex[:6].upper())


class MissionScorer:
    """
    Comprehensive mission scoring system tracking all major events,
    scientific discoveries, and mission milestones.
    """

    ACHIEVEMENTS = [
        Achievement("Saturn Departure",    "Left solar system through wormhole", 100),
        Achievement("Wormhole Transit",    "First humans to traverse a wormhole", 500),
        Achievement("Miller's Data",       "Collected environmental data from Miller's World", 300),
        Achievement("Gargantua Close",     "Approached within 10 r_s of Gargantua", 400),
        Achievement("Mann Betrayal Survived","Survived Dr. Mann's deception", 200),
        Achievement("Gargantua Slingshot", "Executed relativistic gravity assist", 600),
        Achievement("Tesseract Entry",     "Cooper entered 5D tesseract structure", 1000),
        Achievement("TARS Singularity",    "TARS retrieved quantum gravity data", 2000),
        Achievement("Plan A Complete",     "Murphy solved gravity equation", 3000),
        Achievement("Plan B Enacted",      "Brand established colony on Edmunds' Planet", 2000),
        Achievement("Humanity Survives",   "Species successfully evacuated Earth", 5000),
        Achievement("First Contact Proxy", "Interacted with evolved humanity (5D beings)", 1500),
    ]

    def __init__(self):
        self.achievements = [Achievement(a.name, a.description, a.points)
                             for a in self.ACHIEVEMENTS]
        self.custom_events: List[Dict] = []

    def unlock(self, name: str) -> Optional[Achievement]:
        for a in self.achievements:
            if a.name == name and not a.unlocked:
                a.unlocked = True
                return a
        return None

    def total_score(self) -> int:
        return sum(a.points for a in self.achievements if a.unlocked)

    def max_score(self) -> int:
        return sum(a.points for a in self.achievements)

    def completion_pct(self) -> float:
        return self.total_score() / self.max_score() * 100

    def add_event(self, name: str, description: str, points: int):
        self.custom_events.append({"name": name, "description": description,
                                   "points": points, "time": time.time()})

    def achievements_df(self) -> pd.DataFrame:
        rows = [{"Achievement": a.name, "Description": a.description,
                 "Points": a.points, "Unlocked": "✓" if a.unlocked else "—",
                 "Value": a.points if a.unlocked else 0}
                for a in self.achievements]
        return pd.DataFrame(rows)

    def mission_outcome(self) -> MissionOutcome:
        pct = self.completion_pct()
        if pct >= 90:  return MissionOutcome.COMPLETE_A
        if pct >= 60:  return MissionOutcome.COMPLETE_B
        if pct >= 30:  return MissionOutcome.PARTIAL
        return MissionOutcome.ONGOING


# ══════════════════════════════════════════════════════════════════════════════
# §7  DATA DRIVE SYSTEM
# ══════════════════════════════════════════════════════════════════════════════
@dataclass
class DataDrive:
    """Mission data drive for transmission to NASA."""
    drive_id:    str   = field(default_factory=lambda: uuid.uuid4().hex[:12].upper())
    timestamp:   float = field(default_factory=time.time)
    data_type:   str   = "SCIENCE_PACKAGE"
    payload:     str   = ""
    size_bytes:  int   = 0
    sha256:      str   = ""
    status:      DriveStatus = DriveStatus.PENDING

    def compute_hash(self) -> str:
        self.sha256 = hashlib.sha256(self.payload.encode()).hexdigest()
        return self.sha256

    def verify(self, received_payload: str) -> bool:
        return hashlib.sha256(received_payload.encode()).hexdigest() == self.sha256

    def to_dict(self) -> Dict:
        return {"Drive ID": self.drive_id,
                "Timestamp": time.strftime("%Y-%m-%d %H:%M:%S",
                                            time.localtime(self.timestamp)),
                "Type": self.data_type,
                "Size (bytes)": self.size_bytes,
                "SHA-256": self.sha256[:20]+"...",
                "Status": self.status.value}


class DataDriveSystem:
    """Manage mission data packages and drive submission log."""

    def __init__(self):
        self.drives: List[DataDrive] = []

    def create_drive(self, data_type: str, payload: str) -> DataDrive:
        drive = DataDrive(data_type=data_type, payload=payload,
                          size_bytes=len(payload.encode()))
        drive.compute_hash()
        drive.status = DriveStatus.SUBMITTED
        self.drives.append(drive)
        return drive

    def build_lazarus_package(self, archive: LazarusArchive) -> DataDrive:
        payload = json.dumps(archive.to_dataframe().to_dict(), indent=2)
        return self.create_drive("LAZARUS_ARCHIVE", payload)

    def build_tars_crystal_package(self, quantum_bits: int,
                                    integrity: float) -> DataDrive:
        payload = json.dumps({
            "quantum_bits": quantum_bits,
            "integrity": integrity,
            "singularity_depth": quantum_bits**0.333,
            "timestamp_Earth": time.time(),
        }, indent=2)
        return self.create_drive("TARS_CRYSTAL_DATA", payload)

    def build_plan_summary_package(self, plan_a: PlanAEngine,
                                    plan_b: PlanBEngine) -> DataDrive:
        payload = json.dumps({
            "plan_A": plan_a.summary(),
            "plan_B": plan_b.summary(),
        }, indent=2)
        return self.create_drive("PLAN_AB_STATUS", payload)

    def drive_log_df(self) -> pd.DataFrame:
        if not self.drives:
            return pd.DataFrame()
        return pd.DataFrame([d.to_dict() for d in self.drives])

    def verify_all(self) -> Dict[str, int]:
        verified = corrupted = 0
        for d in self.drives:
            if d.verify(d.payload):
                d.status = DriveStatus.VERIFIED; verified += 1
            else:
                d.status = DriveStatus.CORRUPTED; corrupted += 1
        return {"verified": verified, "corrupted": corrupted}


# ══════════════════════════════════════════════════════════════════════════════
# §8  SESSION STATE
# ══════════════════════════════════════════════════════════════════════════════
def init_mission_session():
    D: Dict[str, Any] = {
        "mr_archive":      LazarusArchive(),
        "mr_plan_a":       PlanAEngine(44.0, 0.0),
        "mr_plan_b":       PlanBEngine(PLAN_B_EMBRYOS, 0.78),
        "mr_scorer":       MissionScorer(),
        "mr_drives":       DataDriveSystem(),
        "mr_years":        44.0,
        "mr_sing_data":    0.0,
        "mr_n_embryos":    PLAN_B_EMBRYOS,
        "mr_planet_esi":   0.78,
        "mr_pop_df":       None,
        "mr_plan_a_summ":  None,
        "mr_plan_b_summ":  None,
    }
    for k, v in D.items():
        if k not in st.session_state:
            st.session_state[k] = v

_MPL_MR = {
    "figure.facecolor": "#060810","axes.facecolor": "#08090e",
    "axes.edgecolor": "#141830","axes.labelcolor": "#E8C46A",
    "axes.grid": True,"grid.color": "#0c1020","grid.linestyle": ":",
    "grid.alpha": 0.5,"xtick.color": "#354060","ytick.color": "#354060",
    "xtick.labelsize": 6,"ytick.labelsize": 6,"axes.labelsize": 7,
    "axes.titlesize": 8,"axes.titlecolor": "#E8C46A","text.color": "#E8C46A",
    "font.family": "monospace","legend.facecolor": "#08090e",
    "legend.edgecolor": "#141830","legend.fontsize": 6,
    "figure.dpi": 110,"savefig.facecolor": "#060810",
    "axes.spines.top": False,"axes.spines.right": False,
}
def _mpl_mr(): plt.rcParams.update(_MPL_MR)


# ══════════════════════════════════════════════════════════════════════════════
# §9  PLOTTING
# ══════════════════════════════════════════════════════════════════════════════
def _plot_lazarus_overview(archive: LazarusArchive) -> plt.Figure:
    _mpl_mr()
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    fig.patch.set_facecolor("#060810")
    df = archive.to_dataframe()
    tl = archive.signal_quality_timeline()
    status_colors = {
        "CONFIRMED VIABLE":"#81C784","VIABLE CANDIDATE":"#4FC3F7",
        "MARGINAL — uncertain":"#FFB74D","DATA FALSIFIED (Mann)":"#EF5350",
        "SIGNAL LOST":"#3a4a70","AGENT DECEASED":"#CE93D8","UNKNOWN":"#555"
    }
    # 1. Signal quality timeline
    ax1 = axes[0]
    for _, row in tl.iterrows():
        clr = "#81C784" if row["Habitable"] else "#EF5350"
        ax1.scatter(row["Year"], row["Quality"], color=clr, s=80,
                    edgecolors="#E8C46A", lw=0.5, zorder=5)
        ax1.annotate(row["Planet"][:10], (row["Year"], row["Quality"]+0.02),
                     fontsize=4.5, color="#888")
    ax1.set_xlabel("Signal received year"); ax1.set_ylabel("Signal quality [0–1]")
    ax1.set_title("LAZARUS SIGNAL QUALITY TIMELINE")
    ax1.set_facecolor("#08090e")
    # 2. Status distribution pie
    ax2 = axes[1]
    st_counts = df["Status"].value_counts()
    clrs_pie  = [status_colors.get(s, "#555") for s in st_counts.index]
    wedges, texts, autos = ax2.pie(
        st_counts.values, labels=st_counts.index, colors=clrs_pie,
        autopct="%1.0f%%", startangle=90,
        textprops={"fontsize":5.5,"color":"#E8C46A"})
    for at in autos: at.set_fontsize(5)
    ax2.set_title("MISSION STATUS DISTRIBUTION")
    # 3. Reliability scores
    ax3 = axes[2]
    reliability = [p.reliability_score() for p in archive.PROBES]
    names       = [p.scientist.split()[-1] for p in archive.PROBES]
    clrs_rel    = [status_colors.get(p.status.value, "#555") for p in archive.PROBES]
    b = ax3.barh(names, reliability, color=clrs_rel, alpha=0.85)
    ax3.bar_label(b, fmt="%.2f", padding=3, fontsize=6, color="#fff")
    ax3.set_xlabel("Reliability score [0–1]")
    ax3.set_title("DATA RELIABILITY BY SCIENTIST")
    ax3.set_facecolor("#08090e")
    plt.tight_layout(); return fig


def _plot_plan_a(plan_a: PlanAEngine) -> plt.Figure:
    _mpl_mr()
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    fig.patch.set_facecolor("#060810")
    # 1. Equation completion surface (years × singularity data)
    ax1 = axes[0]
    yrs_arr  = np.linspace(0, 60, 80)
    sing_arr = np.linspace(0, 100, 80)
    YY, SS   = np.meshgrid(yrs_arr, sing_arr)
    ZZ = np.zeros_like(YY)
    for i in range(80):
        for j in range(80):
            pa = PlanAEngine(YY[i,j], SS[i,j])
            ZZ[i,j] = pa.equation_completion()*100
    c = ax1.contourf(YY, SS, ZZ, levels=20, cmap="plasma")
    plt.colorbar(c, ax=ax1, label="Completion [%]")
    ax1.scatter([plan_a.years_worked],[plan_a.singularity_data_pct],
                color="#E8C46A", s=100, zorder=5, label="Current state")
    ax1.set_xlabel("Years worked"); ax1.set_ylabel("Singularity data [%]")
    ax1.set_title("PLAN A COMPLETION SURFACE")
    ax1.legend(fontsize=6)
    # 2. Station requirements
    ax2 = axes[1]
    params = plan_a.station_parameters()
    cats   = ["Stations\n(×1000)", "Area/Station\n(km²)", "Pop/Station\n(×1000)"]
    vals   = [params["n_stations_needed"]/1000,
              params["station_area_km2"],
              params["people_per_station"]/1000]
    ax2.bar(cats, vals, color=["#E8C46A","#4FC3F7","#81C784"], alpha=0.85)
    ax2.set_title(f"O'NEILL STATION PARAMETERS\n({params['n_stations_needed']:,} stations needed)")
    ax2.set_facecolor("#08090e")
    # 3. Timeline
    ax3 = axes[2]
    tl  = plan_a.timeline()
    ax3.barh(tl["Year"].astype(str), [1]*len(tl), color="#1a2040", alpha=0.5)
    for _, row in tl.iterrows():
        ax3.text(0.05, str(row["Year"]), row["Event"][:45],
                 va="center", fontsize=5.5, color="#E8C46A",
                 transform=ax3.get_yaxis_transform())
    ax3.set_xlabel(""); ax3.set_title("PLAN A TIMELINE")
    ax3.set_facecolor("#08090e")
    plt.tight_layout(); return fig


def _plot_plan_b(plan_b: PlanBEngine) -> plt.Figure:
    _mpl_mr()
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    fig.patch.set_facecolor("#060810")
    pop_df = plan_b.population_model(500)
    # 1. Population growth
    ax1 = axes[0]
    phase_colors = {"Artificial reproduction":"#CE93D8","Early natural repro":"#4FC3F7",
                    "Rapid expansion":"#81C784","Logistic plateau":"#E8C46A"}
    prev_phase = ""; seg_start = 0
    for i, row in pop_df.iterrows():
        phase = row["Phase"]
        if phase != prev_phase and i > 0:
            seg = pop_df.iloc[seg_start:i]
            ax1.semilogy(seg["Year"], seg["Population"],
                         color=phase_colors.get(prev_phase,"#fff"), lw=1.5,
                         label=prev_phase)
            seg_start = i
        prev_phase = phase
    ax1.axhline(plan_b.MVP, color="#EF5350", lw=0.7, ls="--",
                label=f"MVP ({plan_b.MVP})")
    ax1.axhline(1e6, color="#FFB74D", lw=0.7, ls=":",
                label="1 million")
    ax1.set_xlabel("Years post-landing"); ax1.set_ylabel("Colony population")
    ax1.set_title(f"PLAN B COLONY GROWTH\n{plan_b.n_embryos} embryos → {plan_b.esi:.2f} ESI planet")
    ax1.legend(fontsize=5.5)
    # 2. Resource requirements
    ax2 = axes[1]
    pops = [1000, 5000, 50000, 500000, 1e6]
    water = [plan_b.resource_requirements(p)["water_tonnes_yr"] for p in pops]
    food  = [plan_b.resource_requirements(p)["food_tonnes_yr"] for p in pops]
    ax2.loglog(pops, water, color="#4FC3F7", lw=1.2, marker="o", ms=4,
               label="Water (t/yr)")
    ax2.loglog(pops, food,  color="#81C784", lw=1.2, marker="s", ms=4,
               label="Food (t/yr)")
    ax2.set_xlabel("Colony population"); ax2.set_ylabel("Tonnes/year")
    ax2.set_title("RESOURCE REQUIREMENTS vs POPULATION")
    ax2.legend(fontsize=6)
    # 3. Embryo genetic diversity
    ax3 = axes[2]
    n_arr = np.linspace(100, 10000, 200)
    div   = [math.sqrt(n)*2/20000 for n in n_arr]
    ax3.plot(n_arr, div, color="#E8C46A", lw=1.3)
    ax3.axvline(plan_b.n_embryos, color="#EF5350", lw=0.9, ls="--",
                label=f"Plan B: {plan_b.n_embryos} embryos\nDiv={plan_b.genetic_diversity_index():.4f}")
    ax3.axhline(0.05, color="#FFB74D", lw=0.7, ls=":", label="Minimum viable diversity")
    ax3.set_xlabel("Number of embryos"); ax3.set_ylabel("Genetic diversity index")
    ax3.set_title("GENETIC DIVERSITY vs EMBRYO COUNT")
    ax3.legend(fontsize=6)
    plt.tight_layout(); return fig


def _plot_mission_score(scorer: MissionScorer) -> plt.Figure:
    _mpl_mr()
    fig, axes = plt.subplots(1, 2, figsize=(13, 5))
    fig.patch.set_facecolor("#060810")
    df = scorer.achievements_df()
    # Achievement chart
    ax1 = axes[0]
    clrs = ["#81C784" if u=="✓" else "#2a3050" for u in df["Unlocked"]]
    b = ax1.barh(df["Achievement"], df["Points"], color=clrs, alpha=0.85)
    ax1.bar_label(b, fmt="%d pts", padding=3, fontsize=6, color="#fff")
    ax1.set_xlabel("Points"); ax1.set_title(
        f"MISSION ACHIEVEMENTS — Score: {scorer.total_score()}/{scorer.max_score()}\n"
        f"{scorer.completion_pct():.1f}% complete  |  {scorer.mission_outcome().value}")
    ax1.set_facecolor("#08090e")
    # Score breakdown donut
    ax2 = axes[1]
    unlocked   = sum(a.points for a in scorer.achievements if a.unlocked)
    locked     = scorer.max_score() - unlocked
    wedge_vals = [unlocked, locked]
    wedge_clrs = ["#E8C46A","#1a2040"]
    wedge_labs = [f"Earned\n{unlocked:,}pts", f"Remaining\n{locked:,}pts"]
    ax2.pie(wedge_vals, labels=wedge_labs, colors=wedge_clrs,
            startangle=90, wedgeprops={"width":0.5},
            textprops={"fontsize":7,"color":"#E8C46A"})
    ax2.set_title("MISSION SCORE BREAKDOWN")
    plt.tight_layout(); return fig


# ══════════════════════════════════════════════════════════════════════════════
# §10  MAIN PAGE
# ══════════════════════════════════════════════════════════════════════════════
def mission_reporter_page():
    init_mission_session()
    _mpl_mr()
    S = st.session_state

    st.markdown("""
    <div style="border-left:3px solid #FFB74D;padding:.55rem 1.2rem;
                margin-bottom:1.2rem;background:rgba(255,183,77,0.03);
                font-family:monospace;">
    <div style="color:#FFB74D;font-size:.95rem;letter-spacing:.12em;
                font-weight:600;">📋 MISSION REPORTER &amp; LAZARUS ARCHIVE</div>
    <div style="color:#5a6a90;font-size:.62rem;margin-top:.2rem;">
    Lazarus Archive · Plan A Engine · Plan B Colony Model ·
    Mission Scorer · Data Drive System · Mission Outcome Assessment
    </div></div>""", unsafe_allow_html=True)

    (tab_laz, tab_a, tab_b,
     tab_score, tab_drives, tab_outcome) = st.tabs([
        "🔭 LAZARUS ARCHIVE",
        "⚡ PLAN A ENGINE",
        "🌱 PLAN B ENGINE",
        "🏆 MISSION SCORER",
        "💾 DATA DRIVES",
        "📊 MISSION OUTCOME",
    ])

    with tab_laz:
        archive = S["mr_archive"]
        fig = _plot_lazarus_overview(archive)
        st.pyplot(fig, use_container_width=True); plt.close(fig)
        st.markdown('<div style="font-family:monospace;font-size:.62rem;color:#FFB74D;">COMPLETE LAZARUS DATABASE</div>',
                    unsafe_allow_html=True)
        st.dataframe(archive.to_dataframe(), use_container_width=True, hide_index=True)
        st.markdown("**Top Candidates:**")
        for p in archive.top_candidates(3):
            st.markdown(f"&nbsp;&nbsp;◆ **{p.planet_name}** — {p.scientist} — "
                        f"Quality: {p.signal_quality:.2f} — Reliability: {p.reliability_score():.3f}")

    with tab_a:
        c1, c2 = st.columns([1, 3])
        with c1:
            yrs  = st.slider("Years Prof. Brand worked", 0.0, 60.0,
                              float(S["mr_years"]), 0.5)
            sing = st.slider("Singularity data %", 0.0, 100.0,
                              float(S["mr_sing_data"]), 0.5)
            S["mr_years"] = yrs; S["mr_sing_data"] = sing
            plan_a = PlanAEngine(yrs, sing); S["mr_plan_a"] = plan_a
            su_a   = plan_a.summary()
            clr_a  = "#81C784" if su_a["plan_viable"] else "#EF5350"
            st.markdown(f"""
            <div style="font-family:monospace;font-size:.57rem;color:#c0c8e0;
                        background:rgba(8,9,14,.92);padding:.65rem;
                        border:1px solid rgba(255,183,77,.15);border-radius:3px;
                        line-height:2.0;">
            Completion: <b style="color:{clr_a};">{su_a['equation_completion']:.2f}%</b><br>
            Theoretical max: <b>{su_a['theoretical_max_pct']:.2f}%</b><br>
            Stations needed: <b style="color:#E8C46A;">{su_a['stations_needed']:,}</b><br>
            Area/station: <b>{su_a['area_per_station_km2']:.1f} km²</b><br>
            Plan viable: <b style="color:{clr_a};">{"YES" if su_a["plan_viable"] else "NO"}</b><br>
            Status: <b>{su_a['status']}</b>
            </div>""", unsafe_allow_html=True)
            with st.expander("Brand Deception Analysis"):
                dec = plan_a.brand_deception_analysis()
                for k, v in dec.items():
                    st.markdown(f"&nbsp;&nbsp;**{k}**: {v}")
        with c2:
            fig = _plot_plan_a(plan_a)
            st.pyplot(fig, use_container_width=True); plt.close(fig)

    with tab_b:
        c1, c2 = st.columns([1, 3])
        with c1:
            n_emb = st.slider("Number of embryos", 100, 10000,
                               int(S["mr_n_embryos"]), 100)
            esi_p = st.slider("Target planet ESI", 0.1, 1.0,
                               float(S["mr_planet_esi"]), 0.01)
            S["mr_n_embryos"] = n_emb; S["mr_planet_esi"] = esi_p
            plan_b = PlanBEngine(n_emb, esi_p); S["mr_plan_b"] = plan_b
            su_b   = plan_b.summary()
            clr_b  = "#81C784" if su_b["plan_viable"] else "#EF5350"
            st.markdown(f"""
            <div style="font-family:monospace;font-size:.57rem;color:#c0c8e0;
                        background:rgba(8,9,14,.92);padding:.65rem;
                        border:1px solid rgba(255,183,77,.15);border-radius:3px;
                        line-height:2.0;">
            Embryos: <b style="color:#E8C46A;">{su_b['n_embryos']:,}</b><br>
            Target ESI: <b>{su_b['target_esi']:.3f}</b><br>
            Genetic diversity: <b>{su_b['genetic_diversity']:.4f}</b><br>
            MVP met (yr): <b style="color:#81C784;">{su_b['mvp_met_yr']} yr</b><br>
            Pop at 100yr: <b>{su_b['population_100yr']:,.0f}</b><br>
            Carrying capacity: <b>{su_b['carrying_capacity']:.2e}</b><br>
            Land needed: <b>{su_b['land_needed_km2']:.1f} km²</b><br>
            Viable: <b style="color:{clr_b};">{"YES" if su_b["plan_viable"] else "NO"}</b>
            </div>""", unsafe_allow_html=True)
            # Knowledge preservation
            kp = plan_b.knowledge_preservation_estimate()
            st.markdown(f"""
            <div style="font-family:monospace;font-size:.55rem;color:#888;
                        background:rgba(8,9,14,.80);padding:.4rem;
                        border:1px solid rgba(255,183,77,.08);border-radius:3px;
                        margin-top:.3rem;line-height:1.8;">
            <b style="color:#FFB74D;">Knowledge Preservation</b><br>
            Wikipedia: {kp['wikipedia_GB']}GB ·
            Papers: {kp['scientific_papers_TB']}TB<br>
            Books: {kp['all_books_TB']}TB ·
            Ship storage: {kp['ship_storage_TB']}TB<br>
            Coverage: <b>{kp['coverage_pct']:.0f}%</b> ·
            Tech rebuild: {kp['generations_to_rebuild_tech']} gen
            </div>""", unsafe_allow_html=True)
        with c2:
            fig = _plot_plan_b(plan_b)
            st.pyplot(fig, use_container_width=True); plt.close(fig)

    with tab_score:
        scorer = S["mr_scorer"]
        c1, c2 = st.columns([1, 3])
        with c1:
            st.markdown('<div style="font-family:monospace;font-size:.62rem;color:#FFB74D;">UNLOCK ACHIEVEMENTS</div>',
                        unsafe_allow_html=True)
            for ach in scorer.achievements:
                if st.checkbox(f"{ach.name} ({ach.points}pts)",
                               value=ach.unlocked, key=f"ach_{ach.uid}"):
                    ach.unlocked = True
                else:
                    ach.unlocked = False
            st.markdown(f"""
            <div style="font-family:monospace;font-size:.75rem;color:#E8C46A;
                        margin-top:.5rem;">
            Score: {scorer.total_score():,} / {scorer.max_score():,}<br>
            {scorer.completion_pct():.1f}% complete
            </div>""", unsafe_allow_html=True)
        with c2:
            fig = _plot_mission_score(scorer)
            st.pyplot(fig, use_container_width=True); plt.close(fig)
            st.dataframe(scorer.achievements_df(), use_container_width=True, hide_index=True)

    with tab_drives:
        drives = S["mr_drives"]
        archive= S["mr_archive"]
        plan_a = S["mr_plan_a"]
        plan_b = S["mr_plan_b"]
        c1, c2 = st.columns(2)
        with c1:
            if st.button("💾 Build Lazarus Data Package", use_container_width=True):
                drives.build_lazarus_package(archive)
            if st.button("💎 Build TARS Crystal Package", use_container_width=True):
                drives.build_tars_crystal_package(int(2**40*0.97), 0.97)
            if st.button("📋 Build Plan A/B Summary Package", use_container_width=True):
                drives.build_plan_summary_package(plan_a, plan_b)
            if st.button("✓ Verify All Drives", use_container_width=True):
                result = drives.verify_all()
                st.success(f"Verified: {result['verified']}  Corrupted: {result['corrupted']}")
        with c2:
            if not drives.drives:
                st.info("Build data packages to populate drive log.")
            else:
                st.dataframe(drives.drive_log_df(), use_container_width=True, hide_index=True)

    with tab_outcome:
        scorer = S["mr_scorer"]
        plan_a = S["mr_plan_a"]
        plan_b = S["mr_plan_b"]
        outcome = scorer.mission_outcome()
        su_a   = plan_a.summary()
        su_b   = plan_b.summary()
        overall_color = ("#81C784" if "COMPLETE" in outcome.value
                         else "#FFB74D" if "PARTIAL" in outcome.value else "#EF5350")
        st.markdown(f"""
        <div style="border:2px solid {overall_color};padding:1rem;border-radius:5px;
                    background:rgba(8,9,14,.95);font-family:monospace;margin-bottom:1rem;">
        <div style="color:{overall_color};font-size:1.2rem;font-weight:700;letter-spacing:.1em;">
        {outcome.value}
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:.8rem;margin-top:.8rem;">
        <div><div style="color:#888;font-size:.6rem;">MISSION SCORE</div>
             <div style="color:#E8C46A;font-size:1.5rem;">{scorer.total_score():,}</div></div>
        <div><div style="color:#888;font-size:.6rem;">PLAN A STATUS</div>
             <div style="color:{'#81C784' if su_a['plan_viable'] else '#EF5350'};font-size:1rem;">
             {su_a['status']}</div></div>
        <div><div style="color:#888;font-size:.6rem;">PLAN B STATUS</div>
             <div style="color:{'#81C784' if su_b['plan_viable'] else '#EF5350'};font-size:1rem;">
             {su_b['status']}</div></div>
        </div>
        </div>""", unsafe_allow_html=True)
        # Final summary table
        summary_data = {
            "Metric": ["Mission Score", "Achievements Unlocked",
                       "Plan A Completion", "Plan B Embryos",
                       "Colony ESI", "Humanity Status", "Lazarus Viable"],
            "Value":  [f"{scorer.total_score():,}/{scorer.max_score():,}",
                       f"{sum(1 for a in scorer.achievements if a.unlocked)}/{len(scorer.achievements)}",
                       f"{su_a['equation_completion']:.1f}%",
                       f"{su_b['n_embryos']:,}",
                       f"{su_b['target_esi']:.3f}",
                       "EVACUATED" if su_a["plan_viable"] else "PLAN B ONLY",
                       f"{sum(1 for p in archive.PROBES if p.habitable_vote and p.reliability_score()>0.5)}"],
        }
        st.dataframe(pd.DataFrame(summary_data), use_container_width=True, hide_index=True)
